﻿// Decompiled with JetBrains decompiler
// Type: ColorSystemTools.ColorSystemTools
// Assembly: ColorSystemTools, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 51003FB0-01FD-4910-A1B5-0E27A78A2D41
// Assembly location: D:\Work Horizont\casdk_ver430_all\WBAutoAdjTools\ColorSystemTools.exe

using CA200SRVRLib;
using System;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.IO.Ports;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;
using System.Diagnostics;

namespace TVSender
{
  public partial class ColorSystemTools : Form
  {
      private const string WBSetSection = "WBsettings";
		LogUser log;
      #region params
      public float target_Sx = 2800f;
      public float target_Sy = 2900f;
      public float target_Lv = 250f;
      public float ucMeasure_Sx = 2800f;
      public float ucMeasure_Sy = 2900f;
      public float ucMeasure_Lv = 250f;
      public float ucPrevMeasure_Sx = 2800f;
      public float ucPrevMeasure_Sy = 2900f;
      public float ucPrevMeasure_Lv = 250f;
      public int CurrentColorTempMode;
      public byte[,] uColorTemp_Table = new byte[3, 3]
      {
          { (byte) 128, (byte) 128, (byte) 128 },
          { (byte) 128, (byte) 128, (byte) 128 },
          { (byte) 128, (byte) 128, (byte) 128 }
      };
      public byte[,] uColorTempAdj_Data = new byte[3, 3]
      {
          { (byte) 128, (byte) 128, (byte) 128 },
          { (byte) 128, (byte) 128, (byte) 128 },
          { (byte) 128, (byte) 128, (byte) 128 }
      };
      public int SaveDataNumber;
      public int uColorTempMode;
      #endregion
      #region bullshit params
      private SerialPort Port1;
      public int[,] uColorTempStd = new int[3, 2];
      public float[,] uColorTempCurr = new float[3, 3];
      public int[] PassedColorTempModes = new int[3];
      public string uPort1 = "COM4";
      public int uBaudrate = 115200;
      public string uReceiveStr = "";
      public int TVReturnStatus = 1;
      public bool EnableReturnCommand = true;
      public byte Adjust_StepLength = 8;
      public byte Adjust_MaxValue = 128;
      public byte Adjust_MaxValue_Backup = 128;
      public DateTime startTime = new DateTime();
      public DateTime stopTime = new DateTime();
      public DateTime beginningTime = new DateTime();
      public DateTime endTime = new DateTime();
      public TimeSpan ts_total = new TimeSpan();
      public TimeSpan ts_diff = new TimeSpan();
      public int LvMinus_Count = 5;
      public float Panel_Lv_max = 250f;
      public float Brightness_Tolerance = 10f;
      public float Temp_Tolerance = 50f;
      public float Cool_TargetBrightness = 210f;
      public float Standard_TargetBrightness = 210f;
      public float Warm_TargetBrightness = 210f;
      public bool UseMaxPanelLv75Percent = true;
      public bool StandardGGainGreaterThan128 = true;
      public int[,] uColorTemp_StartStepSum = new int[3, 4];
      public int[] uColorTemp_StartStepIndex = new int[3];
      private System.Windows.Forms.Timer timerClock = new System.Windows.Forms.Timer();
      public const string TEMP_DATA_FILE = "temp_data.txt";
      public const string START_DATA_FILE = "start_data.txt";
      public bool uUartReceiveFlag;
      public bool TargetType_Monitor;
      public int Adjust_State;
      public int Adjust_Repeat;
      public int Adjust_Result;
      public int Panel_width;
      public int Panel_height;
      public int Panel_x;
      public int Panel_y;
      public int this_width;
      public int this_height;
      public int this_x;
      public int this_y;
      public ColorSystemTools.InitValue InitValueType;
      public bool SaveDefaultData;
      #endregion       

    public ColorSystemTools()
    {
      this.InitializeComponent();
		log = new LogUser();
      this.Init_mouse();
      this.Init_key();
      this.Init_SerialPort();
      this.Init_Timer();
      this.Init_Var();
      this.Init_SaveFile();
    }
    [DllImport("dll_test4.dll")]
    private static extern int AdjustRGB_ColorTemp(float ucCompare_Sx, float ucCompare_Sy, float ucCompare_Lv, float uMeasure_Sx, float uMeasure_Sy, float uMeasure_Lv, float ucTemp_Bri, float ucTemp_ok, int ucStep);
    public void Init_Timer()
    {
      this.timerClock.Tick += new EventHandler(this.OnTimerEvent);
      this.timerClock.Interval = 75;
      this.timerClock.Start();
    }
    private void Init_mouse()
    {
    }
    private void Init_key()
    {
    }
    private void Init_Var()
    {
      this.richTextBox32.Text = this.Cool_TargetBrightness.ToString();
      this.richTextBox37.Text = this.Standard_TargetBrightness.ToString();
      this.richTextBox38.Text = this.Warm_TargetBrightness.ToString();
      this.richTextBoxToleranceLv.Text = "3";
      this.comboBox4.Text = "65";
      this.comboBox6.Text = "65";
      this.comboBox7.Text = "60";
      this.radioButton1.Checked = true;
      this.radioButton2.Checked = false;

      this.radioButton5.Checked = true;
      this.radioButton6.Checked = false;
      this.radioButton7.Checked = true;
      this.radioButton8.Checked = false;      
      this.uColorTempMode = 0;
      this.comboBoxToleranceXY.Text = "0.005";
      this.Temp_Tolerance = 50f;
      this.PassedColorTempModes[0] = 1;
      this.PassedColorTempModes[1] = 1;
      this.PassedColorTempModes[2] = 1;
      this.LvMinus_Count = 5;
      this.UseMaxPanelLv75Percent = true;
      this.StandardGGainGreaterThan128 = false;
      this.EnableReturnCommand = true;
      this.TargetType_Monitor = false;
      this.Top = 0;
      this.Left = 0;
      this.radioButtonGreen128No.Checked = false;
      this.radioButtonGreen128Yes.Checked = true;      
      this.comboBoxXYPreset.Text = "SINGSUNG_26inches_above";
      SelectPresets();
    }
    private void Init_SaveFile()
    {
      if (!File.Exists("temp_data.txt"))
        return;
      using (StreamReader streamReader = File.OpenText("temp_data.txt"))
      {
        string str;
        while ((str = streamReader.ReadLine()) != null)
        {
          string[] strArray = str.Split(',');
          this.SaveDefaultData = int.Parse(strArray[0]) > 2;
          this.SaveDataNumber = int.Parse(strArray[0]) / 10;
        }
        this.richTextBox20.Text = this.SaveDataNumber.ToString();
        streamReader.Close();
      }
      if (this.SaveDataNumber < 10)
      {
        this.buttonDefault.Enabled = false;
        this.buttonDefault.BackColor = Color.Green;
        this.buttonAverage.Enabled = false;
        this.buttonAverage.BackColor = SystemColors.Control;
        this.InitValueType = ColorSystemTools.InitValue.DefaultValue;
        if (this.SaveDefaultData)
        {
          if (!File.Exists("temp_data.txt"))
            return;
          using (StreamReader streamReader = File.OpenText("temp_data.txt"))
          {
            string str;
            while ((str = streamReader.ReadLine()) != null)
            {
              string[] strArray = str.Split(',');
              if (int.Parse(strArray[0]) == 0)
              {
                this.uColorTemp_Table[0, 0] = byte.Parse(strArray[1]);
                this.uColorTemp_Table[0, 1] = byte.Parse(strArray[2]);
                this.uColorTemp_Table[0, 2] = byte.Parse(strArray[3]);
              }
              else if (int.Parse(strArray[0]) == 1)
              {
                this.uColorTemp_Table[1, 0] = byte.Parse(strArray[1]);
                this.uColorTemp_Table[1, 1] = byte.Parse(strArray[2]);
                this.uColorTemp_Table[1, 2] = byte.Parse(strArray[3]);
              }
              else if (int.Parse(strArray[0]) == 2)
              {
                this.uColorTemp_Table[2, 0] = byte.Parse(strArray[1]);
                this.uColorTemp_Table[2, 1] = byte.Parse(strArray[2]);
                this.uColorTemp_Table[2, 2] = byte.Parse(strArray[3]);
                break;
              }
            }
            streamReader.Close();
          }
        }
        else
        {
          this.uColorTemp_Table[0, 0] = (byte) 128;
          this.uColorTemp_Table[0, 1] = (byte) 128;
          this.uColorTemp_Table[0, 2] = (byte) 128;
          this.uColorTemp_Table[1, 0] = (byte) 128;
          this.uColorTemp_Table[1, 1] = (byte) 128;
          this.uColorTemp_Table[1, 2] = (byte) 128;
          this.uColorTemp_Table[2, 0] = (byte) 128;
          this.uColorTemp_Table[2, 1] = (byte) 128;
          this.uColorTemp_Table[2, 2] = (byte) 128;
        }
      }
      else
      {
        this.buttonDefault.Enabled = true;
        this.buttonDefault.BackColor = SystemColors.Control;
        this.buttonAverage.Enabled = false;
        this.buttonAverage.BackColor = Color.Green;
        this.InitValueType = ColorSystemTools.InitValue.AverageVaule;
        if (!File.Exists("temp_data.txt"))
          return;
        using (StreamReader streamReader = File.OpenText("temp_data.txt"))
        {
          int[] numArray1 = new int[3];
          int[] numArray2 = new int[3];
          int[] numArray3 = new int[3];
          string str;
          while ((str = streamReader.ReadLine()) != null)
          {
            string[] strArray = str.Split(',');
            if (int.Parse(strArray[0]) >= 10)
            {
              numArray1[int.Parse(strArray[0]) % 10] += int.Parse(strArray[1]);
              numArray2[int.Parse(strArray[0]) % 10] += int.Parse(strArray[2]);
              numArray3[int.Parse(strArray[0]) % 10] += int.Parse(strArray[3]);
              this.SaveDataNumber = int.Parse(strArray[0]) / 10;
            }
          }
          try
          {
            this.uColorTemp_Table[0, 0] = (byte) (numArray1[0] / this.SaveDataNumber);
            this.uColorTemp_Table[0, 1] = (byte) (numArray2[0] / this.SaveDataNumber);
            this.uColorTemp_Table[0, 2] = (byte) (numArray3[0] / this.SaveDataNumber);
            this.uColorTemp_Table[1, 0] = (byte) (numArray1[1] / this.SaveDataNumber);
            this.uColorTemp_Table[1, 1] = (byte) (numArray2[1] / this.SaveDataNumber);
            this.uColorTemp_Table[1, 2] = (byte) (numArray3[1] / this.SaveDataNumber);
            this.uColorTemp_Table[2, 0] = (byte) (numArray1[2] / this.SaveDataNumber);
            this.uColorTemp_Table[2, 1] = (byte) (numArray2[2] / this.SaveDataNumber);
            this.uColorTemp_Table[2, 2] = (byte) (numArray3[2] / this.SaveDataNumber);
          }
          catch
          {
            int num = (int) MessageBox.Show(" No saved data. ");
          }
          streamReader.Close();
        }
      }
      this.richTextBox30.Text = this.uColorTemp_Table[0, 0].ToString();
      this.richTextBox27.Text = this.uColorTemp_Table[0, 1].ToString();
      this.richTextBox24.Text = this.uColorTemp_Table[0, 2].ToString();
      this.richTextBox29.Text = this.uColorTemp_Table[1, 0].ToString();
      this.richTextBox26.Text = this.uColorTemp_Table[1, 1].ToString();
      this.richTextBox23.Text = this.uColorTemp_Table[1, 2].ToString();
      this.richTextBox28.Text = this.uColorTemp_Table[2, 0].ToString();
      this.richTextBox25.Text = this.uColorTemp_Table[2, 1].ToString();
      this.richTextBox22.Text = this.uColorTemp_Table[2, 2].ToString();
      this.richTextBoxG.Text = this.uColorTemp_Table[1, 1].ToString();
      if (!File.Exists("start_data.txt"))
        return;
      using (StreamReader streamReader = File.OpenText("start_data.txt"))
      {
        string str;
        while ((str = streamReader.ReadLine()) != null)
        {
          string[] strArray = str.Split(',');
          if (int.Parse(strArray[0]) < 3)
          {
            this.uColorTemp_StartStepSum[int.Parse(strArray[0]), 0] = int.Parse(strArray[1]);
            this.uColorTemp_StartStepSum[int.Parse(strArray[0]), 1] = int.Parse(strArray[2]);
            this.uColorTemp_StartStepSum[int.Parse(strArray[0]), 2] = int.Parse(strArray[3]);
            this.uColorTemp_StartStepSum[int.Parse(strArray[0]), 3] = int.Parse(strArray[4]);
          }
          else if (int.Parse(strArray[0]) == 3)
            this.Adjust_MaxValue_Backup = byte.Parse(strArray[1]);
        }
        streamReader.Close();
      }
      if (this.SaveDataNumber >= 10)
      {
        for (int index1 = 0; index1 < 3; ++index1)
        {
          this.uColorTemp_StartStepIndex[index1] = 0;
          for (int index2 = 1; index2 < 4; ++index2)
          {
            if (this.uColorTemp_StartStepSum[index1, index2] > this.uColorTemp_StartStepSum[index1, this.uColorTemp_StartStepIndex[index1]])
              this.uColorTemp_StartStepIndex[index1] = index2;
          }
        }
        this.richTextBoxCoolLvPercent.Text = (100 - 5 * (5 + this.uColorTemp_StartStepIndex[0])).ToString() + "%";
        this.richTextBoxNormLvPercent.Text = (100 - 5 * (3 + this.uColorTemp_StartStepIndex[1])).ToString() + "%";
        this.richTextBoxWarmLvPercent.Text = (100 - 5 * (5 + this.uColorTemp_StartStepIndex[2])).ToString() + "%";
      }
      else
      {
        this.richTextBoxCoolLvPercent.Text = "75%";
        this.richTextBoxNormLvPercent.Text = "85%";
        this.richTextBoxWarmLvPercent.Text = "75%";
      }
    }
    private void Init_SerialPort()
    {
        Port1 = Code.port;
        Port1.DataReceived += new SerialDataReceivedEventHandler(serialPort1_DataReceived);
      this.Update();
    }
    private void Init_CA210()
    {
      if (PublicData.isConnectedCA210)
      {
        PublicData.m_IMemory.ChannelNO = 90;
        this.DelayXms(50);
        PublicData.m_ICa.SetAnalogRange(2.5f, 2.5f);
        if (PublicData.m_ICa.DisplayMode != 0)
          PublicData.m_ICa.DisplayMode = 0;
        PublicData.m_IMemory.SetChannelID(" ");
        if (PublicData.m_IMemory.ChannelID != "WB AutoAdj")
          PublicData.m_IMemory.SetChannelID("WB AutoAdj");
        this.Measure_CA210();
      }
      else
      {
        int num = (int) MessageBox.Show("CA210 is not connected.");
      }
    }
    private void DisConnect_CA210()
    {
      try
      {
        if (!PublicData.isConnectedCA210)
          return;
        PublicData.m_ICa.RemoteMode = 0;
        PublicData.isConnectedCA210 = false;
        PublicData.uPowerStatus = true;
      }
      catch
      {
        MessageBox.Show("CA210 is not connected.");
      }
    }
    private void Connect_CA210()
    {
      this.buttonConnectUSB.Enabled = false;
      if (!PublicData.uPowerStatus)
      {
        try
        {
          PublicData.m_ICa200.AutoConnect();
        }
        catch
        {
          int num = (int) MessageBox.Show("Error! Check USB connection please.");
          this.buttonConnectUSB.Enabled = true;
          return;
        }
        this.DelayXms(50);
        PublicData.uPowerStatus = true;
        PublicData.isConnectedCA210 = true;
        PublicData.m_ICas = (ICas) PublicData.m_ICa200.Cas;          
        PublicData.m_ICa = (ICa) PublicData.m_ICas.get_ItemOfNumber(1);
        PublicData.m_IProbe = (IProbe) PublicData.m_ICa.SingleProbe;
        PublicData.m_IMemory = (IMemory) PublicData.m_ICa.Memory;
      }
      else if (!PublicData.isConnectedCA210)
      {
        try
        {
          PublicData.m_ICa.RemoteMode = 1;
          PublicData.uPowerStatus = true;
          PublicData.isConnectedCA210 = true;
        }
        catch
        {
          int num = (int) MessageBox.Show("Error! Check USB connection please.");
          return;
        }
      }
      this.DelayXms(50);
      try
      {
        this.Init_CA210();
      }
      catch
      {
        PublicData.m_ICa.RemoteMode = 0;
        PublicData.isConnectedCA210 = false;
        int num = (int) MessageBox.Show("Error! Try again.");
      }
    }

    bool isLogMeasure = false;
    private void Measure_CA210()
    {
      checkMeasure();
      this.ucPrevMeasure_Sx = this.ucMeasure_Sx;
      this.ucPrevMeasure_Sy = this.ucMeasure_Sy;
      this.ucPrevMeasure_Lv = this.ucMeasure_Lv;
      this.ucMeasure_Sx = PublicData.m_IProbe.sx * 10000f;
      this.ucMeasure_Sy = PublicData.m_IProbe.sy * 10000f;
      this.ucMeasure_Lv = PublicData.m_IProbe.Lv;
      if (isLogMeasure)
      {
          ToLog("before", new float[]{ ucMeasure_Sx, ucMeasure_Sy, ucMeasure_Lv } );
      }
      isLogMeasure = false;
    }
    private void checkMeasure()
    {
        try
        {
            PublicData.m_ICa.Measure(1);
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message);
            if (ex.Message == "Communication Port Error\n--fail USB sending\n--check hard")
            {
            }
        }
    }
    private void ToLog(string msg, float[] income)
    {
        //string path = @"\\Fserver-366\SoftWare\Журнал записи прошивок на USB";
        //string date = DateTime.Now.ToString("dd.MM.yyyy");
        if (PublicData.IDDataTV == null) return;
        //PublicData.TVDataID = "WB log";
        string path = "wb"+PublicData.IDDataTV + ".txt"; //"log.txt";
        path = Path.Combine(PublicData.LogsWBPath, path);
        string time = DateTime.Now.ToString("HH:mm:ss");
        string who = string.Format("{0}({1})", Environment.MachineName, Environment.UserName);
        string header = string.Format("[{0}] ", PublicData.IDDataTV);
        
        string message = string.Format
            (
            "{3} : x={0}, y={1}, Lv={2}{4}",
            (income[0] / 10000f).ToString().Substring(0,5),
            (income[1] / 10000f).ToString().Substring(0,5),
            income[2].ToString().Substring(0,5),
            msg,
            Environment.NewLine
            );
        string add = (msg == "after ") ? Environment.NewLine : "";
        try
        {            
            for (int i = 0; i < 10; i++)
            {
                try
                {
                    File.AppendAllText(path, header + message + add);
                }
                catch (UnauthorizedAccessException ex1)
                {
                    LogUser Log = new LogUser();
                    if (!Log.isLogIn)
                    {
                        MessageBox.Show(string.Format("Нельзя записать лог баланса белого:{0}"
                            + "Не удалось получить администраторские права.{0}{1}", 
                            Environment.NewLine, ex1.Message));
                        return;
                    }
                    try
                    {
                        File.AppendAllText(path, header + message + add);
                    }
                    catch
                    {
                        MessageBox.Show(string.Format("Нельзя записать лог баланса белого:{0}"
                            + "Администраторские права получены.{0}{1}",
                            Environment.NewLine, ex1.Message));
                        return;
                    }
                    finally
                    {
                        Log.Out();
                    }
                    break;
                }
                catch (Exception ex)
                {
                    Thread.Sleep(500);
                    if (i == 9) throw ex;
                }
                break;
            }

            //System.Diagnostics.Process.Start(path);//test
            //Log.Out();
        }
        catch (Exception ex) { Trace.WriteLine(ex.Message); }     
    }

    private void UartSendDelay(int x)
    {
      int num = 0;
      do
      {
        for (int index = 0; index < (int) ushort.MaxValue; ++index)
          ++num;
        --x;
      }
      while (x > 0);
    }
    private void DelayXms(int x)
    {
      int num = 0;
      do
      {
        for (int index = 0; index < (int) ushort.MaxValue; ++index)
          ++num;
        --x;
      }
      while (x > 0);
    }
    private float PERCENT(float x, float ucCompare_Lv)
    {
      return (float) ((double) this.ABS(x, ucCompare_Lv) / (double) ucCompare_Lv * 100.0);
    }
    private float ABS(float x, float y)
    {
      if ((double) x >= (double) y)
        return x - y;
      return y - x;
    }
    private float MAX(float x, float y)
    {
      if ((double) x > (double) y)
        return x;
      return y;
    }
    private float MIN(float x, float y)
    {
      if ((double) x < (double) y)
        return x;
      return y;
    }
    private void ColorTempAdjStepUpdate(int uCompare_Step)
    {
      if (uCompare_Step == 0)
      {
        this.target_Sx = (float) this.uColorTempStd[0, 0];
        this.target_Sy = (float) this.uColorTempStd[0, 1];
      }
      else if (uCompare_Step == 1)
      {
        this.target_Sx = (float) this.uColorTempStd[1, 0];
        this.target_Sy = (float) this.uColorTempStd[1, 1];
      }
      else if (uCompare_Step == 2)
      {
        this.target_Sx = (float) this.uColorTempStd[2, 0];
        this.target_Sy = (float) this.uColorTempStd[2, 1];
      }
      else
      {
        this.target_Sx = (float) this.uColorTempStd[0, 0];
        this.target_Sy = (float) this.uColorTempStd[0, 1];
      }
    }
    private void SetCurrentColorTempMode(int uMode)
    {
      this.CurrentColorTempMode = uMode;
    }
    private int GetCurrentColorTempMode()
    {
      return this.CurrentColorTempMode;
    }
    private bool check(float stand_low_value, float stand_high_value, float currrent_value)
    {
      return (double) stand_high_value >= (double) currrent_value && (double) stand_low_value <= (double) currrent_value;
    }
    private bool Check_lv_ok(float lv_compare, float lv_distance)
    {
      return this.check(lv_compare - lv_distance, lv_compare + lv_distance, this.ucMeasure_Lv);
    }
    private bool Check_y_temp_ok(float fy_type, float fxy_distance)
    {
      return this.check(fy_type - fxy_distance, fy_type + fxy_distance, this.ucMeasure_Sy);
    }
    private bool Check_x_temp_ok(float fx_type, float fxy_distance)
    {
      return this.check(fx_type - fxy_distance, fx_type + fxy_distance, this.ucMeasure_Sx);
    }
    private bool Check_temp_ok(float fx_type, float fy_type, float fxy_distance)
    {
      return this.check(fy_type - fxy_distance, fy_type + fxy_distance, this.ucMeasure_Sy) && this.check(fx_type - fxy_distance, fx_type + fxy_distance, this.ucMeasure_Sx);
    }
    private bool Check_lv_temp_ok(float fx_type, float fy_type, float fxy_distance, float lv_compare, float lv_distance)
    {
      return this.check(fy_type - fxy_distance, fy_type + fxy_distance, this.ucMeasure_Sy) && this.check(fx_type - fxy_distance, fx_type + fxy_distance, this.ucMeasure_Sx) && this.check(lv_compare - lv_distance, lv_compare + lv_distance, this.ucMeasure_Lv);
    }
    private bool Check_RGB_saturation()
    {
      return (double) this.ABS(this.ucPrevMeasure_Lv, this.ucMeasure_Lv) < 2.0;
    }
    private bool Check_saturation()
    {
      return (double) this.ABS(this.ucPrevMeasure_Lv, this.ucMeasure_Lv) < 0.5 && (double) this.ABS(this.ucPrevMeasure_Sy, this.ucMeasure_Sy) < 5.0 && (double) this.ABS(this.ucPrevMeasure_Sx, this.ucMeasure_Sx) < 5.0;
    }

    public void OnTimerEvent(object myObject, EventArgs myEventArgs)
    {
        
      switch (this.Adjust_State)
      #region useless cases
      {
          #region roll
          case 0:
          this.Adjust_Repeat = 0;
              
          this.Adjust_State = 0;
          break;
              #endregion
        case 1:
          this.startTime = DateTime.Now;
            #region roll
          this.richTextBox3.Text = "Time: ";
          this.timerClock.Interval = !this.EnableReturnCommand ? 160 : 80;
          this.timerClock.Start();
          this.Adjust_Repeat = 0;
          if (!this.send_normal_com((byte) 16, (byte) 1, (byte) 0, (byte) 0))
          {
            this.Adjust_State = 2;
            break;
          }
          break;
              #endregion
        case 2:
          if (this.check_cmd_return())
              #region roll
          {
            this.Adjust_Repeat = 0;
            if (!this.send_normal_com((byte) 11, (byte) 0, (byte) 0, (byte) 0))
            {
              this.Adjust_State = 3;
              break;
            }
            break;
          }
          ++this.Adjust_Repeat;
          if (this.Adjust_Repeat > 15)
          {
            this.Adjust_Repeat = 0;
            if (!this.send_normal_com((byte) 16, (byte) 1, (byte) 0, (byte) 0))
              break;
            break;
          }
          break;
              #endregion
        case 3:
          if (this.check_cmd_return())
              #region roll
          {
              #region bullshit
              this.PassedColorTempModes[0] = 1;
            this.PassedColorTempModes[1] = 1;
            this.PassedColorTempModes[2] = 1;
            this.richTextBoxCoolX.Text = "";
            this.richTextBoxMaxLv.Text = "";
            this.richTextBoxCoolY.Text = "";
            this.richTextBoxCoolLv.Text = "";
            this.richTextBoxNormX.Text = "";
            this.richTextBoxNormY.Text = "";
            this.richTextBoxNormLv.Text = "";
            this.richTextBoxWarmX.Text = "";
            this.richTextBoxWarmY.Text = "";
            this.richTextBoxWarmLv.Text = "";
            this.richTextBox21.Text = "";
            this.richTextBoxCoolLvPercent.Text = "";
            this.richTextBoxNormLvPercent.Text = "";
            this.richTextBoxWarmLvPercent.Text = "";
            this.richTextBoxG.Text = "";
            this.Adjust_Result = 0;
            this.Adjust_Repeat = 0;
              #endregion
            if (this.UseMaxPanelLv75Percent)
              this.LvMinus_Count = this.InitValueType != ColorSystemTools.InitValue.DefaultValue ? (this.uColorTempMode != 15 ? 5 + this.uColorTemp_StartStepIndex[0] : 7 + this.uColorTemp_StartStepIndex[0]) : (this.uColorTempMode != 15 ? 5 : 7);
            if (!this.TargetType_Monitor)
            {
              if (this.InitValueType == ColorSystemTools.InitValue.DefaultValue)
              {
                this.timerClock.Interval = !this.EnableReturnCommand ? 150 : 65;
                this.Adjust_State = 10;
                break;
              }
              this.Adjust_MaxValue = this.Adjust_MaxValue_Backup;
              this.timerClock.Interval = !this.EnableReturnCommand ? 200 : 75;

              this.SetCurrentColorTempMode(1);
              this.send_normal_com(1, (byte)this.GetCurrentColorTempMode(), 0, 0);

              this.Adjust_State = 14;
              break;
            }
            this.Adjust_MaxValue = (byte) 128;
            this.timerClock.Interval = !this.EnableReturnCommand ? 200 : 75;

            this.SetCurrentColorTempMode(1);
            this.send_normal_com(1, (byte)this.GetCurrentColorTempMode(), 0, 0);

            this.Adjust_State = 14;
            break;
          }
          ++this.Adjust_Repeat;
          if (this.Adjust_Repeat > 15)
          {
            this.Adjust_Repeat = 0;
            if (!this.send_normal_com((byte) 11, (byte) 0, (byte) 0, (byte) 0))
              break;
            break;
          }
          break;
              #endregion
        case 10:
          this.Adjust_Repeat = 0;
              #region roll
          this.SetCurrentColorTempMode(1);
          if (!this.send_normal_com((byte) 1, (byte) this.GetCurrentColorTempMode(), (byte) 0, (byte) 0))
          {
              this.Adjust_State = 11;
              break;
          }
          break;
              #endregion
        case 11:
          if (this.check_cmd_return())
              #region roll
          {
            isLogMeasure = true;
            Measure_CA210();
            this.Adjust_Repeat = 0;
            this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 0] = (byte) 128;
            this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 1] = (byte) 128;
            this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 2] = (byte) 128;
            Thread.Sleep(200);
            if (!this.send_normal_com((byte) 12, this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 0], this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 1], this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 2]))
            {
              this.Adjust_State = 12;
              break;
            }
            break;
          }
          ++this.Adjust_Repeat;
          if (this.Adjust_Repeat > 15)
          {
            this.Adjust_Repeat = 0;
            if (!this.send_normal_com((byte) 1, (byte) this.GetCurrentColorTempMode(), (byte) 0, (byte) 0))
              break;
            break;
          }
          break;
              #endregion
        case 12:
          if (this.check_cmd_return())
              #region roll
          {
            this.Adjust_Repeat = 0;
            this.Measure_CA210();
            if ((double) this.ucMeasure_Lv < 100.0)
            {
              this.Adjust_State = 99;
              break;
            }
            this.Adjust_StepLength = (byte) 8;
            this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 0] += this.Adjust_StepLength;
            this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 1] += this.Adjust_StepLength;
            this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 2] += this.Adjust_StepLength;
            if (!this.send_normal_com((byte) 12, this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 0], this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 1], this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 2]))
            {
              this.Adjust_State = 13;
              break;
            }
            break;
          }
          ++this.Adjust_Repeat;
          if (this.Adjust_Repeat > 15)
          {
            this.Adjust_Repeat = 0;
            if (!this.send_normal_com((byte) 12, this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 0], this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 1], this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 2]))
              break;
            break;
          }
          break;
              #endregion
        case 13:
          if (this.check_cmd_return())
              #region roll
          {
            this.Adjust_Repeat = 0;
            this.Measure_CA210();
            if ((double) this.ucMeasure_Lv < 100.0)
            {
              this.Adjust_State = 99;
              break;
            }
            if (this.Check_RGB_saturation())
            {
              this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 0] -= (byte) ((uint) this.Adjust_StepLength * 2U);
              this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 1] -= (byte) ((uint) this.Adjust_StepLength * 2U);
              this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 2] -= (byte) ((uint) this.Adjust_StepLength * 2U);
              this.Adjust_StepLength = (byte) ((uint) this.Adjust_StepLength / 2U);
              if ((int) this.Adjust_StepLength == 1)
              {
                this.Adjust_MaxValue = this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 1];
                if ((int) this.Adjust_MaxValue < (int) this.Adjust_MaxValue_Backup)
                  this.Adjust_MaxValue = this.Adjust_MaxValue_Backup;
                else if (this.InitValueType == ColorSystemTools.InitValue.DefaultValue)
                  this.Adjust_MaxValue_Backup = this.Adjust_MaxValue;
                this.timerClock.Interval = !this.EnableReturnCommand ? 200 : 75;
                this.Adjust_State = 14;
                break;
              }
            }
            else
            {
              this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 0] += this.Adjust_StepLength;
              this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 1] += this.Adjust_StepLength;
              this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 2] += this.Adjust_StepLength;
            }
            if (!this.send_normal_com((byte) 12, this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 0], this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 1], this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 2]))
            {
              this.Adjust_State = 13;
              break;
            }
            break;
          }
          ++this.Adjust_Repeat;
          if (this.Adjust_Repeat > 15)
          {
            this.Adjust_Repeat = 0;
            if (!this.send_normal_com((byte) 12, this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 0], this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 1], this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 2]))
              break;
            break;
          }
          break;
              #endregion
        case 14:
          this.Adjust_Repeat = 0;
              #region roll
          Thread.Sleep(200);
          isLogMeasure = true;
          Measure_CA210();
          Thread.Sleep(100);
          if (!this.send_normal_com((byte) 10, (byte) 1, (byte) 0, (byte) 0))
          {
            this.Adjust_State = 15;
            break;
          }
          break;
              #endregion
        case 15:
          if (this.check_cmd_return())
              #region roll
          {
            this.Adjust_Repeat = 0;
            this.Measure_CA210();
            this.Panel_Lv_max = this.ucMeasure_Lv;
            this.richTextBoxMaxLv.Text = this.Panel_Lv_max.ToString().Substring(0, 5);
            if ((double) this.Panel_Lv_max < 100.0)
            {
              this.Adjust_State = 99;
              break;
            }
            if (!this.send_normal_com((byte) 10, (byte) 0, (byte) 0, (byte) 0))
            {
              this.Adjust_State = 25;
              break;
            }
            break;
          }
          ++this.Adjust_Repeat;
          if (this.Adjust_Repeat > 15)
          {
            this.Adjust_Repeat = 0;
            if (!this.send_normal_com((byte) 10, (byte) 1, (byte) 0, (byte) 0))
              break;
            break;
          }
          break;
              #endregion
        case 25:
          if (this.check_cmd_return())
              #region roll
          {
            this.Adjust_Repeat = 0;
            this.SetCurrentColorTempMode(0);
            this.timerClock.Interval = !this.EnableReturnCommand ? 160 : 65;
            this.Adjust_State = 26;
            break;
          }
          ++this.Adjust_Repeat;
          if (this.Adjust_Repeat > 15)
          {
            this.Adjust_Repeat = 0;
            if (!this.send_normal_com((byte) 10, (byte) 0, (byte) 0, (byte) 0))
              break;
            break;
          }
          break;
              #endregion
        case 26:
          this.Adjust_Repeat = 0;
              #region roll
          this.beginningTime = DateTime.Now;
          this.ColorTempAdjStepUpdate(this.GetCurrentColorTempMode());
          this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 0] = (int) this.uColorTemp_Table[this.GetCurrentColorTempMode(), 0] <= (int) this.Adjust_MaxValue ? this.uColorTemp_Table[this.GetCurrentColorTempMode(), 0] : this.Adjust_MaxValue;
          this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 1] = (int) this.uColorTemp_Table[this.GetCurrentColorTempMode(), 1] <= (int) this.Adjust_MaxValue ? this.uColorTemp_Table[this.GetCurrentColorTempMode(), 1] : this.Adjust_MaxValue;
          this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 2] = (int) this.uColorTemp_Table[this.GetCurrentColorTempMode(), 2] <= (int) this.Adjust_MaxValue ? this.uColorTemp_Table[this.GetCurrentColorTempMode(), 2] : this.Adjust_MaxValue;
          if (!this.send_normal_com((byte) 1, (byte) this.GetCurrentColorTempMode(), (byte) 0, (byte) 0))
          {
            this.Adjust_State = 27;
            break;
          }
          break;
              #endregion
        case 27:
          if (this.check_cmd_return())
              #region roll
          {
            this.Adjust_Repeat = 0;
            if (!this.send_normal_com((byte) 12, this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 0], this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 1], this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 2]))
            {
              if (this.UseMaxPanelLv75Percent)
              {
                if (this.uColorTempMode == 15)
                {
                  if (this.GetCurrentColorTempMode() == 0)
                    this.target_Lv = (float) ((double) float.Parse(this.comboBox4.Text) * (double) this.Panel_Lv_max / 100.0);
                  else if (this.GetCurrentColorTempMode() == 1)
                    this.target_Lv = (float) ((double) float.Parse(this.comboBox6.Text) * (double) this.Panel_Lv_max / 100.0);
                  else if (this.GetCurrentColorTempMode() == 2)
                    this.target_Lv = (float) ((double) float.Parse(this.comboBox7.Text) * (double) this.Panel_Lv_max / 100.0);
                }
                else
                  this.target_Lv = this.Panel_Lv_max * (float) (1.0 - 0.05 * (double) this.LvMinus_Count);
              }
              else if (this.GetCurrentColorTempMode() == 0)
                this.target_Lv = this.Cool_TargetBrightness;
              else if (this.GetCurrentColorTempMode() == 1)
                this.target_Lv = this.Standard_TargetBrightness;
              else if (this.GetCurrentColorTempMode() == 2)
                this.target_Lv = this.Warm_TargetBrightness;
              this.Brightness_Tolerance = (float) ((double) float.Parse(this.richTextBoxToleranceLv.Text) * (double) this.Panel_Lv_max / 100.0);
              this.Adjust_StepLength = (byte) 2;
              this.Adjust_State = 30;
              break;
            }
            break;
          }
          ++this.Adjust_Repeat;
          if (this.Adjust_Repeat > 15)
          {
            this.Adjust_Repeat = 0;
            if (!this.send_normal_com((byte) 1, (byte) this.GetCurrentColorTempMode(), (byte) 0, (byte) 0))
              break;
            break;
          }
          break;
              #endregion
#endregion    
          //check temp
        case 30:
          if (this.check_cmd_return())
              #region Check temp
          {
            this.Adjust_Repeat = 0;
            this.Measure_CA210();
            if ((double) this.ucMeasure_Lv < 100.0)
            {
              this.Adjust_State = 99;
              break;
            }
            if (this.Check_lv_temp_ok(this.target_Sx, this.target_Sy, this.Temp_Tolerance, this.target_Lv, this.Brightness_Tolerance))
            {
              if ((double) this.ucMeasure_Sx < (double) this.ucMeasure_Sy)
              {
                this.PassedColorTempModes[this.GetCurrentColorTempMode()] = 0;
                this.Adjust_State = 98;
                break;
              }
              this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 0] -= (byte) 6;
              ++this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 1];
              this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 2] -= (byte) 2;
              if (!this.send_normal_com((byte) 12, this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 0], this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 1], this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 2]))
              {
                this.Adjust_State = 30;
                break;
              }
              break;
            }
            this.Adjust_State = 31;
            this.endTime = DateTime.Now;
            this.ts_diff = this.endTime - this.beginningTime;
            //удалить строку ниже
            this.ts_diff = TimeSpan.FromSeconds(5);
            if (this.ts_diff.TotalSeconds > 15.0)
            {
              this.Adjust_State = 99;
              break;
            }
            if (!this.send_normal_com((byte) 12, this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 0], this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 1], this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 2]))
              break;
            break;
          }
          ++this.Adjust_Repeat;
          if (this.Adjust_Repeat > 15)
          {
            this.Adjust_Repeat = 0;
            if (!this.send_normal_com((byte) 12, this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 0], this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 1], this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 2]))
              break;
            break;
          }
          break;
              #endregion        
        case 31:
          //алгоримт Lv
          if (this.check_cmd_return())
          #region алгоритм Lv
          {
            this.Adjust_Repeat = 0;
            this.Measure_CA210();
            if ((double) this.ucMeasure_Lv < 100.0)
            {
              this.Adjust_State = 99;
              break;
            }
            if (!this.Check_lv_ok(this.target_Lv, this.Brightness_Tolerance))
            {   //заменить this.ABS(this.ucMeasure_Lv, this.uCompare_Lv) переменной
              this.Adjust_StepLength = (double) this.ABS(this.ucMeasure_Lv, this.target_Lv) <= 10.0 ? (byte) 2 : (byte) ((double) this.ABS(this.ucMeasure_Lv, this.target_Lv) / 10.0 * 3.0);
              if ((double) this.ucMeasure_Lv > (double) this.target_Lv)
                this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 1] -= this.Adjust_StepLength;
              else if ((int) this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 1] < (int) this.Adjust_MaxValue - (int) this.Adjust_StepLength)
              {
                this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 1] += this.Adjust_StepLength;
              }
              else
              {
                if ((int) this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 1] >= (int) this.Adjust_MaxValue)
                {
                  this.Adjust_State = 34;
                  break;
                }
                this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 1] = this.Adjust_MaxValue;
              }
              this.Adjust_State = 31;
            }
            else
              this.Adjust_State = 32;
            if (!this.send_normal_com((byte) 12, this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 0], this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 1], this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 2]))
              break;
            break;
          }
          ++this.Adjust_Repeat;
          if (this.Adjust_Repeat > 15)
          {
            this.Adjust_Repeat = 0;
            if (!this.send_normal_com((byte) 12, this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 0], this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 1], this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 2]))
              break;
            break;
          }
          break;
              #endregion        
        case 32:
          //алгоритм Y
          if (this.check_cmd_return())
          #region алгоритм Y
          {
            this.Adjust_Repeat = 0;
            this.Measure_CA210();
            if ((double) this.ucMeasure_Lv < 100.0)
            {
              this.Adjust_State = 99;
              break;
            }
            if (!this.Check_y_temp_ok(this.target_Sy, this.Temp_Tolerance))
            {
              this.Adjust_StepLength = (double) this.ABS(this.ucMeasure_Sy, this.target_Sy) <= 100.0 ? (byte) 2 : (byte) ((double) this.ABS(this.ucMeasure_Sy, this.target_Sy) / 100.0 * 3.0);
              if ((double) this.ucMeasure_Sy > (double) this.target_Sy)
              {
                if ((int) this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 2] <= (int) this.Adjust_MaxValue - (int) this.Adjust_StepLength)
                {
                  this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 2] += this.Adjust_StepLength;
                }
                else
                {
                  if ((int) this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 2] >= (int) this.Adjust_MaxValue)
                  {
                    this.Adjust_State = 34;
                    break;
                  }
                  this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 2] = this.Adjust_MaxValue;
                }
              }
              else
                this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 2] -= this.Adjust_StepLength;
              this.Adjust_State = 32;
            }
            else
              this.Adjust_State = 33;
            if (!this.send_normal_com((byte) 12, this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 0], this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 1], this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 2]))
              break;
            break;
          }
          ++this.Adjust_Repeat;
          if (this.Adjust_Repeat > 15)
          {
            this.Adjust_Repeat = 0;
            if (!this.send_normal_com((byte) 12, this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 0], this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 1], this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 2]))
              break;
            break;
          }
          break;
              #endregion        
        case 33:
          //алгоритм X
          if (this.check_cmd_return())
          #region алгоритм X
          {
            this.Adjust_Repeat = 0;
            this.Measure_CA210();
            if ((double) this.ucMeasure_Lv < 100.0)
            {
              this.Adjust_State = 99;
              break;
            }
            if (!this.Check_x_temp_ok(this.target_Sx, this.Temp_Tolerance))
            {
              this.Adjust_StepLength = (double) this.ABS(this.ucMeasure_Sx, this.target_Sx) <= 35.0 ? (byte) 2 : (byte) ((double) this.ABS(this.ucMeasure_Sx, this.target_Sx) / 35.0 * 3.0);
              if ((double) this.ucMeasure_Sx > (double) this.target_Sx)
                this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 0] -= this.Adjust_StepLength;
              else if ((int) this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 0] <= (int) this.Adjust_MaxValue - (int) this.Adjust_StepLength)
              {
                this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 0] += this.Adjust_StepLength;
              }
              else
              {
                if ((int) this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 0] >= (int) this.Adjust_MaxValue)
                {
                  this.Adjust_State = 34;
                  break;
                }
                this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 0] = this.Adjust_MaxValue;
              }
              this.Adjust_State = 33;
            }
            else
              this.Adjust_State = 30;
            if (!this.send_normal_com((byte) 12, this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 0], this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 1], this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 2]))
              break;
            break;
          }
          ++this.Adjust_Repeat;
          if (this.Adjust_Repeat > 15)
          {
            this.Adjust_Repeat = 0;
            if (!this.send_normal_com((byte) 12, this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 0], this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 1], this.uColorTempAdj_Data[this.GetCurrentColorTempMode(), 2]))
              break;
            break;
          }
          break;
              #endregion
        case 34:
          if (this.UseMaxPanelLv75Percent)
              #region roll
          {
            this.Adjust_Repeat = 0;
            ++this.LvMinus_Count;
            this.Adjust_State = 26;
            if (this.uColorTempMode == 15)
            {
              this.LvMinus_Count = 7;
              this.PassedColorTempModes[this.GetCurrentColorTempMode()] = 1;
              this.Adjust_State = 99;
              break;
            }
            if (this.GetCurrentColorTempMode() == 0)
            {
              if (this.LvMinus_Count > 7)
              {
                this.LvMinus_Count = 5;
                this.PassedColorTempModes[this.GetCurrentColorTempMode()] = 1;
                this.Adjust_State = 99;
                break;
              }
              break;
            }
            if (this.GetCurrentColorTempMode() == 1)
            {
              if (this.LvMinus_Count > 6)
              {
                this.LvMinus_Count = 5;
                this.PassedColorTempModes[this.GetCurrentColorTempMode()] = 1;
                this.Adjust_State = 99;
                break;
              }
              break;
            }
            if (this.GetCurrentColorTempMode() == 2 && this.LvMinus_Count > 8)
            {
              this.LvMinus_Count = 5;
              this.PassedColorTempModes[this.GetCurrentColorTempMode()] = 1;
              this.Adjust_State = 99;
              break;
            }
            break;
          }
          this.PassedColorTempModes[this.GetCurrentColorTempMode()] = 1;
          this.Adjust_State = 99;
          break;
              #endregion        
        case 98:
          //занесение результата
          this.Adjust_Repeat = 0;
              #region result
          #region cool
          if (this.GetCurrentColorTempMode() == 0)
          {
            this.uColorTempCurr[0, 0] = this.ucMeasure_Sx / 10000f;
            this.richTextBoxCoolX.Text = this.uColorTempCurr[0, 0].ToString().Substring(0, 5);
            this.uColorTempCurr[0, 1] = this.ucMeasure_Sy / 10000f;
            this.richTextBoxCoolY.Text = this.uColorTempCurr[0, 1].ToString().Substring(0, 5);
            this.uColorTempCurr[0, 2] = this.ucMeasure_Lv;
            this.richTextBoxCoolLv.Text = this.uColorTempCurr[0, 2].ToString().Substring(0, 5);
            this.richTextBoxCoolLvPercent.ReadOnly = true;
            this.richTextBoxCoolLvPercent.BackColor = SystemColors.Control;
            if (this.UseMaxPanelLv75Percent)
            {
              if (this.uColorTempMode == 15)
              {
                this.richTextBoxCoolLvPercent.Text = ((int) ((double) this.ucMeasure_Lv / (double) this.Panel_Lv_max * 100.0)).ToString() + "%";
                this.richTextBoxCoolLvPercent.ForeColor = Color.Green;
              }
              else
              {
                this.richTextBoxCoolLvPercent.Text = (100 - this.LvMinus_Count * 5).ToString() + "%";
                if (this.LvMinus_Count > 5)
                  this.richTextBoxCoolLvPercent.ForeColor = Color.Red;
                else
                  this.richTextBoxCoolLvPercent.ForeColor = Color.Green;
                if (this.InitValueType == ColorSystemTools.InitValue.DefaultValue)
                {
                  if (this.uColorTempMode == 15)
                    ++this.uColorTemp_StartStepSum[0, this.LvMinus_Count - 7];
                  else
                    ++this.uColorTemp_StartStepSum[0, this.LvMinus_Count - 5];
                }
              }
            }
            else
            {
              this.richTextBoxCoolLvPercent.Text = ((int) ((double) this.ucMeasure_Lv / (double) this.Panel_Lv_max * 100.0)).ToString() + "%";
              if ((int) ((double) this.ucMeasure_Lv / (double) this.Panel_Lv_max * 100.0) < 75)
                this.richTextBoxCoolLvPercent.ForeColor = Color.Red;
              else
                this.richTextBoxCoolLvPercent.ForeColor = Color.Green;
            }
          }
          #endregion
          #region norm
          else if (this.GetCurrentColorTempMode() == 1)
          {
            this.uColorTempCurr[1, 0] = this.ucMeasure_Sx / 10000f;
            this.richTextBoxNormX.Text = this.uColorTempCurr[1, 0].ToString().Substring(0, 5);
            this.uColorTempCurr[1, 1] = this.ucMeasure_Sy / 10000f;
            this.richTextBoxNormY.Text = this.uColorTempCurr[1, 1].ToString().Substring(0, 5);
            this.uColorTempCurr[1, 2] = this.ucMeasure_Lv;
            this.richTextBoxNormLv.Text = this.uColorTempCurr[1, 2].ToString().Substring(0, 5);
            ToLog("after ", new float[] { ucMeasure_Sx, ucMeasure_Sy, ucMeasure_Lv });
            this.richTextBoxG.ReadOnly = true;
            this.richTextBoxG.Text = this.uColorTempAdj_Data[1, 1].ToString();
            this.richTextBoxG.BackColor = SystemColors.Control;
            if ((int) this.uColorTempAdj_Data[1, 1] < 128)
              this.richTextBoxG.ForeColor = Color.Red;
            else
              this.richTextBoxG.ForeColor = Color.Green;
            this.richTextBoxNormLvPercent.ReadOnly = true;
            this.richTextBoxNormLvPercent.BackColor = SystemColors.Control;
            if (this.UseMaxPanelLv75Percent)
            {
              if (this.uColorTempMode == 15)
              {
                this.richTextBoxNormLvPercent.Text = ((int) ((double) this.ucMeasure_Lv / (double) this.Panel_Lv_max * 100.0)).ToString() + "%";
                this.richTextBoxNormLvPercent.ForeColor = Color.Green;
              }
              else
              {
                this.richTextBoxNormLvPercent.Text = (100 - this.LvMinus_Count * 5).ToString() + "%";
                if (this.LvMinus_Count > 5)
                  this.richTextBoxNormLvPercent.ForeColor = Color.Red;
                else
                  this.richTextBoxNormLvPercent.ForeColor = Color.Green;
                if (this.InitValueType == ColorSystemTools.InitValue.DefaultValue)
                {
                  if (this.uColorTempMode == 15)
                    ++this.uColorTemp_StartStepSum[1, this.LvMinus_Count - 7];
                  else
                    ++this.uColorTemp_StartStepSum[1, this.LvMinus_Count - 3];
                }
              }
            }
            else
            {
              this.richTextBoxNormLvPercent.Text = ((int) ((double) this.ucMeasure_Lv / (double) this.Panel_Lv_max * 100.0)).ToString() + "%";
              if ((int) ((double) this.ucMeasure_Lv / (double) this.Panel_Lv_max * 100.0) < 75)
                this.richTextBoxNormLvPercent.ForeColor = Color.Red;
              else
                this.richTextBoxNormLvPercent.ForeColor = Color.Green;
            }
          }
          #endregion
          #region warm
          else if (this.GetCurrentColorTempMode() == 2)
          {
            this.uColorTempCurr[2, 0] = this.ucMeasure_Sx / 10000f;
            this.richTextBoxWarmX.Text = this.uColorTempCurr[2, 0].ToString().Substring(0, 5);
            this.uColorTempCurr[2, 1] = this.ucMeasure_Sy / 10000f;
            this.richTextBoxWarmY.Text = this.uColorTempCurr[2, 1].ToString().Substring(0, 5);
            this.uColorTempCurr[2, 2] = this.ucMeasure_Lv;
            this.richTextBoxWarmLv.Text = this.uColorTempCurr[2, 2].ToString().Substring(0, 5);
            this.richTextBoxWarmLvPercent.ReadOnly = true;
            this.richTextBoxWarmLvPercent.BackColor = SystemColors.Control;
            if (this.UseMaxPanelLv75Percent)
            {
              if (this.uColorTempMode == 15)
              {
                this.richTextBoxWarmLvPercent.Text = ((int) ((double) this.ucMeasure_Lv / (double) this.Panel_Lv_max * 100.0)).ToString() + "%";
                this.richTextBoxWarmLvPercent.ForeColor = Color.Green;
              }
              else
              {
                this.richTextBoxWarmLvPercent.Text = (100 - this.LvMinus_Count * 5).ToString() + "%";
                if (this.LvMinus_Count > 5)
                  this.richTextBoxWarmLvPercent.ForeColor = Color.Red;
                else
                  this.richTextBoxWarmLvPercent.ForeColor = Color.Green;
                if (this.InitValueType == ColorSystemTools.InitValue.DefaultValue)
                {
                  if (this.uColorTempMode == 15)
                    ++this.uColorTemp_StartStepSum[2, this.LvMinus_Count - 7];
                  else
                    ++this.uColorTemp_StartStepSum[2, this.LvMinus_Count - 5];
                }
              }
            }
            else
            {
              this.richTextBoxWarmLvPercent.Text = ((int) ((double) this.ucMeasure_Lv / (double) this.Panel_Lv_max * 100.0)).ToString() + "%";
              if ((int) ((double) this.ucMeasure_Lv / (double) this.Panel_Lv_max * 100.0) < 75)
                this.richTextBoxWarmLvPercent.ForeColor = Color.Red;
              else
                this.richTextBoxWarmLvPercent.ForeColor = Color.Green;
            }
          }
#endregion
          #region hz
          while (this.PassedColorTempModes[this.GetCurrentColorTempMode()] == 0)
          {
            ++this.CurrentColorTempMode;
            if (this.GetCurrentColorTempMode() > 2)
            {
              this.Adjust_State = !this.EnableReturnCommand ? 101 : 99;
              break;
            }
          }
          if (this.GetCurrentColorTempMode() <= 2)
          {
            if (this.UseMaxPanelLv75Percent)
            {
              if (this.InitValueType == ColorSystemTools.InitValue.DefaultValue)
              {
                if (this.uColorTempMode == 15)
                  this.LvMinus_Count = 7;
                else if (this.GetCurrentColorTempMode() == 1)
                  this.LvMinus_Count = 3;
                else if (this.GetCurrentColorTempMode() == 2)
                  this.LvMinus_Count = 5;
              }
              else if (this.uColorTempMode == 15)
              {
                if (this.GetCurrentColorTempMode() == 1)
                  this.LvMinus_Count = 7 + this.uColorTemp_StartStepIndex[1];
                else if (this.GetCurrentColorTempMode() == 2)
                  this.LvMinus_Count = 7 + this.uColorTemp_StartStepIndex[2];
              }
              else if (this.GetCurrentColorTempMode() == 1)
                this.LvMinus_Count = 3 + this.uColorTemp_StartStepIndex[1];
              else if (this.GetCurrentColorTempMode() == 2)
                this.LvMinus_Count = 5 + this.uColorTemp_StartStepIndex[2];
            }
            this.Adjust_State = 26;
            break;
          }
          break;
#endregion
              #endregion
        #region useless cases
        case 99:
          this.Adjust_Repeat = 0;
              #region roll
          if (this.PassedColorTempModes[0] == 0 && this.PassedColorTempModes[1] == 0 && this.PassedColorTempModes[2] == 0)
          {
            if (this.StandardGGainGreaterThan128 && (int) this.uColorTempAdj_Data[1, 1] < 128)
            {
              this.Adjust_Result = 2;
              this.Adjust_State = 120;
              break;
            }
            if (!this.send_normal_com((byte) 8, (byte) 0, (byte) 0, (byte) 0))
            {
              this.timerClock.Interval = !this.EnableReturnCommand ? 200 : 100;
              this.Adjust_State = 100;
              break;
            }
            break;
          }
          this.Adjust_Result = 1;
          this.Adjust_State = 120;
          break;
              #endregion
        case 100:
          this.Adjust_Repeat = 0;
              #region roll
          this.Adjust_State = 110;
          break;
              #endregion
        case 101:
          this.Adjust_Repeat = 0;
              #region roll
          if (this.PassedColorTempModes[0] == 0)
          {
            this.SetCurrentColorTempMode(0);
            this.ColorTempAdjStepUpdate(this.GetCurrentColorTempMode());
            if (!this.send_normal_com((byte) 1, (byte) this.GetCurrentColorTempMode(), (byte) 0, (byte) 0))
            {
              this.Adjust_State = 102;
              break;
            }
            break;
          }
          this.Adjust_State = 99;
          break;
              #endregion
        case 102:
          if (this.check_cmd_return())
              #region roll
          {
            this.Adjust_Repeat = 0;
            this.Measure_CA210();
            if ((double) this.ucMeasure_Lv < 100.0)
            {
              this.Adjust_State = 99;
              break;
            }
            if (this.Check_temp_ok(this.target_Sx, this.target_Sy, this.Temp_Tolerance + 50f))
            {
              this.Adjust_State = 103;
              break;
            }
            this.PassedColorTempModes[0] = 1;
            this.richTextBoxCoolLvPercent.Text = "";
            this.Adjust_State = 26;
            break;
          }
          ++this.Adjust_Repeat;
          if (this.Adjust_Repeat > 15)
          {
            this.Adjust_Repeat = 0;
            if (!this.send_normal_com((byte) 1, (byte) this.GetCurrentColorTempMode(), (byte) 0, (byte) 0))
              break;
            break;
          }
          break;
              #endregion
        case 103:
          this.Adjust_Repeat = 0;
              #region roll
          if (this.PassedColorTempModes[2] == 0)
          {
            this.SetCurrentColorTempMode(2);
            this.ColorTempAdjStepUpdate(this.GetCurrentColorTempMode());
            if (!this.send_normal_com((byte) 1, (byte) this.GetCurrentColorTempMode(), (byte) 0, (byte) 0))
            {
              this.Adjust_State = 104;
              break;
            }
            break;
          }
          this.Adjust_State = 99;
          break;
              #endregion
        case 104:
          if (this.check_cmd_return())
              #region roll
          {
            this.Adjust_Repeat = 0;
            this.Measure_CA210();
            if ((double) this.ucMeasure_Lv < 100.0)
            {
              this.Adjust_State = 99;
              break;
            }
            if (this.Check_temp_ok(this.target_Sx, this.target_Sy, this.Temp_Tolerance + 50f))
            {
              this.Adjust_State = 105;
              break;
            }
            this.PassedColorTempModes[2] = 1;
            this.richTextBoxWarmLvPercent.Text = "";
            this.Adjust_State = 26;
            break;
          }
          ++this.Adjust_Repeat;
          if (this.Adjust_Repeat > 15)
          {
            this.Adjust_Repeat = 0;
            if (!this.send_normal_com((byte) 1, (byte) this.GetCurrentColorTempMode(), (byte) 0, (byte) 0))
              break;
            break;
          }
          break;
              #endregion
        case 105:
          this.Adjust_Repeat = 0;
              #region roll
          if (this.PassedColorTempModes[1] == 0)
          {
            this.SetCurrentColorTempMode(1);
            this.ColorTempAdjStepUpdate(this.GetCurrentColorTempMode());
            if (!this.send_normal_com((byte) 1, (byte) this.GetCurrentColorTempMode(), (byte) 0, (byte) 0))
            {
              this.Adjust_State = 106;
              break;
            }
            break;
          }
          this.Adjust_State = 99;
          break;
              #endregion
        case 106:
          if (this.check_cmd_return())
              #region roll
          {
            this.Adjust_Repeat = 0;
            this.Measure_CA210();
            if ((double) this.ucMeasure_Lv < 100.0)
            {
              this.Adjust_State = 99;
              break;
            }
            if (this.Check_temp_ok(this.target_Sx, this.target_Sy, this.Temp_Tolerance + 50f))
            {
              this.Adjust_State = 99;
              break;
            }
            this.PassedColorTempModes[1] = 1;
            this.richTextBoxNormLvPercent.Text = "";
            this.richTextBoxG.Text = "";
            this.Adjust_State = 26;
            break;
          }
          ++this.Adjust_Repeat;
          if (this.Adjust_Repeat > 15)
          {
            this.Adjust_Repeat = 0;
            if (!this.send_normal_com((byte) 1, (byte) this.GetCurrentColorTempMode(), (byte) 0, (byte) 0))
              break;
            break;
          }
          break;
              #endregion
        case 110:
          if (this.check_cmd_return())
              #region roll
          {
            this.Adjust_Repeat = 0;
            this.Adjust_State = 111;
            break;
          }
          ++this.Adjust_Repeat;
          if (this.Adjust_Repeat > 15)
          {
            this.Adjust_Repeat = 0;
            if (!this.send_normal_com((byte) 8, (byte) 0, (byte) 0, (byte) 0))
            {
              this.Adjust_State = 100;
              break;
            }
            break;
          }
          break;
              #endregion
        case 111:
          this.Adjust_Repeat = 0;
              #region roll
          if (this.SaveDataNumber < 10)
          {
            this.buttonDefault.Enabled = false;
            this.buttonDefault.BackColor = Color.Green;
            this.buttonAverage.Enabled = false;
            this.buttonAverage.BackColor = SystemColors.Control;
            this.InitValueType = ColorSystemTools.InitValue.DefaultValue;
            ++this.SaveDataNumber;
            this.richTextBox20.Text = this.SaveDataNumber.ToString();
            if (!File.Exists("temp_data.txt"))
              return;
            using (StreamWriter streamWriter = new StreamWriter("temp_data.txt", true))
            {
                streamWriter.WriteLine(
                    this.SaveDataNumber.ToString() + "0," + 
                    this.uColorTempAdj_Data[0, 0].ToString() + "," + 
                    this.uColorTempAdj_Data[0, 1].ToString() + "," + 
                    this.uColorTempAdj_Data[0, 2].ToString()
                    );
                streamWriter.WriteLine(
                    this.SaveDataNumber.ToString() + "1," + 
                    this.uColorTempAdj_Data[1, 0].ToString() + "," + 
                    this.uColorTempAdj_Data[1, 1].ToString() + "," + 
                    this.uColorTempAdj_Data[1, 2].ToString()
                    );
                streamWriter.WriteLine(
                    this.SaveDataNumber.ToString() + "2," + 
                    this.uColorTempAdj_Data[2, 0].ToString() + "," + 
                    this.uColorTempAdj_Data[2, 1].ToString() + "," + 
                    this.uColorTempAdj_Data[2, 2].ToString()
                    );
              streamWriter.Close();
            }
            if (this.SaveDataNumber >= 10)
            {
              this.buttonDefault.Enabled = true;
              this.buttonDefault.BackColor = SystemColors.Control;
              this.buttonAverage.Enabled = false;
              this.buttonAverage.BackColor = Color.Green;
              this.InitValueType = ColorSystemTools.InitValue.AverageVaule;
              if (!File.Exists("temp_data.txt"))
                return;
              using (StreamReader streamReader = File.OpenText("temp_data.txt"))
              {
                int[] numArray1 = new int[3];
                int[] numArray2 = new int[3];
                int[] numArray3 = new int[3];
                string str;
                while ((str = streamReader.ReadLine()) != null)
                {
                  string[] strArray = str.Split(',');
                  if (int.Parse(strArray[0]) >= 10)
                  {
                    numArray1[int.Parse(strArray[0]) % 10] += int.Parse(strArray[1]);
                    numArray2[int.Parse(strArray[0]) % 10] += int.Parse(strArray[2]);
                    numArray3[int.Parse(strArray[0]) % 10] += int.Parse(strArray[3]);
                    this.SaveDataNumber = int.Parse(strArray[0]) / 10;
                  }
                }
                try
                {
                  this.uColorTemp_Table[0, 0] = (byte) (numArray1[0] / this.SaveDataNumber);
                  this.uColorTemp_Table[0, 1] = (byte) (numArray2[0] / this.SaveDataNumber);
                  this.uColorTemp_Table[0, 2] = (byte) (numArray3[0] / this.SaveDataNumber);
                  this.uColorTemp_Table[1, 0] = (byte) (numArray1[1] / this.SaveDataNumber);
                  this.uColorTemp_Table[1, 1] = (byte) (numArray2[1] / this.SaveDataNumber);
                  this.uColorTemp_Table[1, 2] = (byte) (numArray3[1] / this.SaveDataNumber);
                  this.uColorTemp_Table[2, 0] = (byte) (numArray1[2] / this.SaveDataNumber);
                  this.uColorTemp_Table[2, 1] = (byte) (numArray2[2] / this.SaveDataNumber);
                  this.uColorTemp_Table[2, 2] = (byte) (numArray3[2] / this.SaveDataNumber);
                }
                catch
                {
                  int num = (int) MessageBox.Show(" No saved data! ");
                }
                this.richTextBox30.Text = this.uColorTemp_Table[0, 0].ToString();
                this.richTextBox27.Text = this.uColorTemp_Table[0, 1].ToString();
                this.richTextBox24.Text = this.uColorTemp_Table[0, 2].ToString();
                this.richTextBox29.Text = this.uColorTemp_Table[1, 0].ToString();
                this.richTextBox26.Text = this.uColorTemp_Table[1, 1].ToString();
                this.richTextBox23.Text = this.uColorTemp_Table[1, 2].ToString();
                this.richTextBox28.Text = this.uColorTemp_Table[2, 0].ToString();
                this.richTextBox25.Text = this.uColorTemp_Table[2, 1].ToString();
                this.richTextBox22.Text = this.uColorTemp_Table[2, 2].ToString();
                streamReader.Close();
              }
            }
            if (this.UseMaxPanelLv75Percent)
            {
              if (!File.Exists("start_data.txt"))
                return;
              using (StreamWriter streamWriter = new StreamWriter("start_data.txt", false))
              {
                streamWriter.WriteLine(
                    "0" + "," + 
                    this.uColorTemp_StartStepSum[0, 0].ToString() + "," +
                    this.uColorTemp_StartStepSum[0, 1].ToString() + "," +
                    this.uColorTemp_StartStepSum[0, 2].ToString() + "," +
                    this.uColorTemp_StartStepSum[0, 3].ToString()
                    );
                streamWriter.WriteLine(
                    "1" + "," +
                    this.uColorTemp_StartStepSum[1, 0].ToString() + "," +
                    this.uColorTemp_StartStepSum[1, 1].ToString() + "," +
                    this.uColorTemp_StartStepSum[1, 2].ToString() + "," +
                    this.uColorTemp_StartStepSum[1, 3].ToString()
                    );
                streamWriter.WriteLine(
                    "2" + "," +
                    this.uColorTemp_StartStepSum[2, 0].ToString() + "," +
                    this.uColorTemp_StartStepSum[2, 1].ToString() + "," +
                    this.uColorTemp_StartStepSum[2, 2].ToString() + "," +
                    this.uColorTemp_StartStepSum[2, 3].ToString()
                    );
                streamWriter.WriteLine(
                    "3" + "," + this.Adjust_MaxValue_Backup.ToString()
                    );
                streamWriter.Close();
              }
              for (int index1 = 0; index1 < 3; ++index1)
              {
                this.uColorTemp_StartStepIndex[index1] = 0;
                for (int index2 = 1; index2 < 4; ++index2)
                {
                    if (
                        this.uColorTemp_StartStepSum[index1, index2]
                        >
                        this.uColorTemp_StartStepSum[index1, this.uColorTemp_StartStepIndex[index1]])
                    {
                        this.uColorTemp_StartStepIndex[index1] = index2;
                    }
                }
              }
            }
          }
          this.timerClock.Interval = !this.EnableReturnCommand ? 160 : 65;
          this.Adjust_Result = 3;
          this.Adjust_State = 118;
          break;
              #endregion
        case 118:
          this.Adjust_Repeat = 0;
              #region roll
          this.SetCurrentColorTempMode(1);
          if (!this.send_normal_com((byte) 1, (byte) this.GetCurrentColorTempMode(), (byte) 0, (byte) 0))
          {
            this.Adjust_State = 119;
            break;
          }
          break;
              #endregion
        case 119:
          if (this.check_cmd_return())
              #region roll
          {
            this.Adjust_Repeat = 0;
            this.Measure_CA210();
            this.Adjust_State = 120;
            break;
          }
          ++this.Adjust_Repeat;
          if (this.Adjust_Repeat > 15)
          {
            this.Adjust_Repeat = 0;
            if (!this.send_normal_com((byte) 1, (byte) this.GetCurrentColorTempMode(), (byte) 0, (byte) 0))
              break;
            break;
          }
          break;
              #endregion
        case 120:
          this.Adjust_Repeat = 0;
              #region roll
          if (!this.send_normal_com((byte) 16, (byte) 0, (byte) 0, (byte) 0))
          {
            this.Adjust_State = 121;
            break;
          }
          break;
              #endregion
#endregion
        case 121:
          if (this.check_cmd_return())
              #region Final
          {
            if (this.Adjust_Result == 3)
            {
              this.richTextBox21.ForeColor = Color.Green;
              this.richTextBox21.Text = "Pass";
              this.DialogResult = DialogResult.OK;
            }
            else if (this.Adjust_Result == 2)
            {
              this.richTextBox21.ForeColor = Color.Yellow;
              this.richTextBox21.Text = "Fail";
              //this.DialogResult = DialogResult.Cancel;
            }
            else
            {
              this.richTextBox21.ForeColor = Color.Red;
              this.richTextBox21.Text = "Fail";
              //this.DialogResult = DialogResult.Cancel;
            }
            this.Adjust_State = 0;
            this.Adjust_Repeat = 0;
            this.Adjust_Result = 0;
            this.stopTime = DateTime.Now;
            this.ts_total = this.stopTime - this.startTime;
            this.buttonStart.Text = "Start";
            buttonStart.Enabled = true;
            this.buttonConnectUSB.Enabled = true;
            //buttonConnectUSB.Text = "Disconnect CA210";
            this.richTextBox3.Text = "Time: " + ((int) this.ts_total.TotalSeconds).ToString() + "s";
            break;
          }
          ++this.Adjust_Repeat;
          if (this.Adjust_Repeat > 15)
          {
            this.Adjust_Repeat = 0;
            this.send_normal_com((byte) 16, (byte) 0, (byte) 0, (byte) 0);
            break;
          }
          break;
          #endregion
      }        
      RecheckLayout();
    }
    private bool send_normal_com(byte com, byte value1, byte value2, byte value3)
    {
        byte[] buffer = new byte[7]
            {
                0xab, (byte) 7, com, value1, value2, value3, 0
            };
        buffer[6] = (byte)
            (
              (uint)byte.MaxValue - (uint)(byte)
              (
                  (int)byte.MaxValue &
                  (int)buffer[0] + (int)buffer[1] + (int)buffer[2] +
                  (int)buffer[3] + (int)buffer[4] + (int)buffer[5]
              )
            );
        try
        {
            if (PublicData.port1)
                this.Port1.Write(buffer, 0, (int)buffer[1]);
        }
        catch
        {
            //this.serialPort1.Close();
            //this.uRS232Connect = false;
            this.richTextBox21.ForeColor = Color.Red;
            this.richTextBox21.Text = "Fail";
            this.buttonSave.Enabled = true;
            //this.buttonSave.Text = "Open serial port";
            this.buttonConnectUSB.Enabled = true;
            //this.buttonStart.Enabled = false;
            //this.buttonStart.Text = "Start";
            this.Adjust_State = 0;
            int num = (int)MessageBox.Show("Serial port is disconnected, please check USB cable!\n" +
                "And reopen the WBAA tool.");
            return true;
        }
        return false;
    }
    private void serialPort1_DataReceived(object sender, SerialDataReceivedEventArgs e)
    {
        if (this.TargetType_Monitor)
            Thread.Sleep(100);
        else
            Thread.Sleep(20);
        try
        {
            int bytesToRead = this.Port1.BytesToRead;
            byte[] buffer = new byte[bytesToRead];
            int num1 = this.Port1.Read(buffer, 0, bytesToRead);
            if (num1 == 12 && (int)buffer[0] == 172 && (int)buffer[1] == 12)
            {
                if ((int)(byte)((int)byte.MaxValue - ((int)byte.MaxValue & (int)buffer[0] + (int)buffer[1]
                    + (int)buffer[2] + (int)buffer[3] + (int)buffer[4] + (int)buffer[5] + (int)buffer[6]
                    + (int)buffer[7] + (int)buffer[8] + (int)buffer[9] + (int)buffer[10]))
                    == (int)buffer[11]
                    )
                #region roll
                {
                    
                    this.uUartReceiveFlag = true;
                    this.TVReturnStatus = 0;
                    if (this.InitValueType != ColorSystemTools.InitValue.DefaultValue || this.SaveDefaultData)
                        return;
                    this.uColorTemp_Table[0, 0] = buffer[2];
                    this.uColorTemp_Table[0, 1] = buffer[3];
                    this.uColorTemp_Table[0, 2] = buffer[4];
                    this.uColorTemp_Table[1, 0] = buffer[5];
                    this.uColorTemp_Table[1, 1] = buffer[6];
                    this.uColorTemp_Table[1, 2] = buffer[7];
                    this.uColorTemp_Table[2, 0] = buffer[8];
                    this.uColorTemp_Table[2, 1] = buffer[9];
                    this.uColorTemp_Table[2, 2] = buffer[10];
                    if (!File.Exists("temp_data.txt"))
                        return;
                    using (StreamWriter streamWriter = new StreamWriter("temp_data.txt", false))
                    {
                        streamWriter.WriteLine(
                            "0," +
                            this.uColorTemp_Table[0, 0].ToString() + "," +
                            this.uColorTemp_Table[0, 1].ToString() + "," +
                            this.uColorTemp_Table[0, 2].ToString()
                            );
                        streamWriter.WriteLine(
                            "1," +
                            this.uColorTemp_Table[1, 0].ToString() + "," +
                            this.uColorTemp_Table[1, 1].ToString() + "," +
                            this.uColorTemp_Table[1, 2].ToString()
                            );
                        streamWriter.WriteLine(
                            "2," +
                            this.uColorTemp_Table[2, 0].ToString() + "," +
                            this.uColorTemp_Table[2, 1].ToString() + "," +
                            this.uColorTemp_Table[2, 2].ToString()
                            );
                        streamWriter.Close();
                    }
                    this.SaveDefaultData = true;
                    this.BeginInvoke((MethodInvoker)(() =>
                    {
                        this.richTextBox30.Text = this.uColorTemp_Table[0, 0].ToString();
                        this.richTextBox27.Text = this.uColorTemp_Table[0, 1].ToString();
                        this.richTextBox24.Text = this.uColorTemp_Table[0, 2].ToString();
                        this.richTextBox29.Text = this.uColorTemp_Table[1, 0].ToString();
                        this.richTextBox26.Text = this.uColorTemp_Table[1, 1].ToString();
                        this.richTextBox23.Text = this.uColorTemp_Table[1, 2].ToString();
                        this.richTextBox28.Text = this.uColorTemp_Table[2, 0].ToString();
                        this.richTextBox25.Text = this.uColorTemp_Table[2, 1].ToString();
                        this.richTextBox22.Text = this.uColorTemp_Table[2, 2].ToString();
                        this.richTextBoxG.Text = this.uColorTemp_Table[1, 1].ToString();
                    }));
                }
                else
                    this.BeginInvoke((MethodInvoker)(() =>
                    {
                        //this.serialPort1.Close();
                        //this.uRS232Connect = false;
                        this.richTextBox21.ForeColor = Color.Red;
                        this.richTextBox21.Text = "Fail";
                        this.buttonSave.Enabled = true;
                        this.buttonSave.Text = "Open serial port";
                        this.buttonConnectUSB.Enabled = true;
                        this.buttonStart.Enabled = false;
                        this.buttonStart.Text = "Start";
                        this.Adjust_State = 0;
                        int num = (int)MessageBox.Show("Getting TV defalt RGB Gain failed.");
                    }));
            }
                #endregion
            else
            {
                if (num1 != 4 || (int)buffer[0] != 172 || ((int)buffer[1] != 4 ||
                    (int)(byte)((int)byte.MaxValue - ((int)byte.MaxValue & (int)buffer[0] +
                    (int)buffer[1] + (int)buffer[2])) != (int)buffer[3])
                    )
                    return;
                this.uUartReceiveFlag = true;
                if ((int)buffer[2] == 0)
                    this.TVReturnStatus = 0;
                else
                    this.TVReturnStatus = 1;
            }
        }
        catch (Exception ex)
        {
            #region catch
            this.BeginInvoke((MethodInvoker)(() =>
            {
                //this.serialPort1.Close();
                //this.uRS232Connect = false;
                this.richTextBox21.ForeColor = Color.Red;
                this.richTextBox21.Text = "Fail";
                this.buttonSave.Enabled = true;
                this.buttonSave.Text = "Open serial port";
                this.buttonConnectUSB.Enabled = true;
                this.buttonStart.Enabled = false;
                this.buttonStart.Text = "Start";
                this.Adjust_State = 0;
                MessageBox.Show("Serial port is disconnected.");
            }));
            #endregion
        }
    }

    private void RecheckLayout()
    {
        if (PublicData.port1)
            this.richTextBox1.Text = " Serial port: " + this.Port1.PortName.ToString() + " opened";
        else
            this.richTextBox1.Text = " Serial port: " + this.Port1.PortName.ToString() + " closed";
        if (PublicData.isConnectedCA210)
            this.richTextBox1.Text = this.richTextBox1.Text + "           CA210 is connected";
        else
            this.richTextBox1.Text = this.richTextBox1.Text + "           CA210 is disconnected";
        if (this.PassedColorTempModes[0] == 1)
            this.richTextBox2.Text = "  Cool NG     ";
        else
            this.richTextBox2.Text = "  Cool OK     ";
        if (this.PassedColorTempModes[1] == 1)
            this.richTextBox2.Text = this.richTextBox2.Text + " Standard NG     ";
        else
            this.richTextBox2.Text = this.richTextBox2.Text + " Standard OK     ";
        if (this.PassedColorTempModes[2] == 1)
            this.richTextBox2.Text = this.richTextBox2.Text + " Warm NG ";
        else
            this.richTextBox2.Text = this.richTextBox2.Text + " Warm OK ";
    }    
    private void ColorSystemTools_FormClosing(object sender, FormClosingEventArgs e)
    {
        Port1.DataReceived -= serialPort1_DataReceived;
		  log.Out();
    }
    private void comboBox1_TextChanged(object sender, EventArgs e)
    {
      //this.uPort1 = this.comboBox1.Text;
      //this.serialPort1.PortName = this.uPort1;
    }
    private void comboBox3_TextChanged(object sender, EventArgs e)
    {
      //this.uBaudrate = Convert.ToInt32(this.comboBox3.Text);
      //this.serialPort1.BaudRate = this.uBaudrate;
    }
    private void buttonSave_Click(object sender, EventArgs e)
    {
        Save();
    }

    private void Save()
    {
		string fileEnd = TVSender.Properties.Settings.Default.FileEndOptions;
		 try
		 {
			 var set = new SavingManager(WBSetSection + fileEnd);
			 set.Key(Setting.CoolX).Value = richTextBox4.Text;
			 set.Key(Setting.CoolY).Value = richTextBox5.Text;
			 set.Key(Setting.WarmX).Value = richTextBox6.Text;
			 set.Key(Setting.WarmY).Value = richTextBox7.Text;
			 set.Key(Setting.StandartX).Value = richTextBox8.Text;
			 set.Key(Setting.StandartY).Value = richTextBox9.Text;
			 set.Key(Setting.ToleranceXY).Value = comboBoxToleranceXY.Text;
			 set.Key(Setting.Green128Below).ValueBool = radioButtonGreen128Yes.Checked;
			 set.Save();
		 }
		 catch (Exception ex)
		 {
			 MessageBox.Show(WBSetSection + "Error.\n"+ex.Message);
		 }
    }

    private void OpenPort()
    {
        //try
        //{
        //    if (this.uRS232Connect)
        //    {
        //        this.Port1.Close();
        //        //this.uRS232Connect = false;
        //        this.buttonOpenPort.Text = "Open serial port";
        //        this.buttonStart.Enabled = false;
        //        this.comboBox1.Enabled = true;
        //        this.comboBox3.Enabled = true;
        //    }
        //    else
        //    {
        //        this.Port1.Open();
        //        //this.uRS232Connect = true;
        //        this.buttonOpenPort.Text = "Close serial port";
        //        if (this.uRS232Connect && PublicData.isConnectedCA210)
        //        {
        //            this.buttonStart.Enabled = true;
        //            this.buttonStart.Focus();
        //        }
        //        this.comboBox1.Enabled = false;
        //        this.comboBox3.Enabled = false;
        //    }
        //}
        //catch
        //{
        //    //this.Port1.Close();
        //    this.uRS232Connect = false;
        //    int num = (int)MessageBox.Show("Error, check serial port connection please!");
        //}
    }
    private void buttonConnectUSB_Click(object sender, EventArgs e)
    {
            buttonStart.Enabled = false;
            buttonConnectUSB.Enabled = false;
            try
            {
                PublicData.m_ICa.Measure(1);
            }
            catch (Exception ex)
            {
                try
                {
                    PublicData.m_ICa.RemoteMode = 1;
                }
                catch (Exception ex2)
                {
                    PublicData.Connect_CA210();
                }
            }
            //buttonConnectUSB.Text = "Disconnect CA210";
            buttonStart.Enabled = true;
            buttonConnectUSB.Enabled = true;              
    }
    private void buttonStart_Click(object sender, EventArgs e)
    {
        Start();
    }

    private void Start()
    {
        if (PublicData.isConnectedCA210)
        {
            if (this.Adjust_State == 0)
            {
                this.Adjust_State = 1;
                this.buttonStart.Text = "Stop";
                this.richTextBox21.Text = "";
                this.buttonSave.Enabled = false;
                this.buttonConnectUSB.Enabled = false;
            }
            else
            {
                this.Adjust_Result = 1;
                this.Adjust_State = 120;
            }
        }
        else
        {
            MessageBox.Show("Connect CA210 please.");
        }
    }
    protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
    {

        if (keyData == Keys.Enter)
        {
            buttonStart.PerformClick();            
            return true;
        }
        if (keyData == Keys.Escape)
        {
            this.Close();
            return true;
        }
        return base.ProcessCmdKey(ref msg, keyData);
    }
    private void ColorSystemTools_KeyPress(object sender, KeyPressEventArgs e)
    {
      if (e.KeyChar != 13 && e.KeyChar != 32)
        return;
      if (PublicData.port1 && PublicData.isConnectedCA210)
      {
        if (this.Adjust_State == 0)
        {
          this.Adjust_State = 1;
          this.buttonStart.Text = "Stop";
          this.richTextBox21.Text = "";
          this.buttonSave.Enabled = false;
          this.buttonConnectUSB.Enabled = false;
        }
        else
        {
          this.Adjust_Result = 1;
          this.Adjust_State = 120;
        }
      }
      else
      {
        int num = (int) MessageBox.Show("Open serial port and connect CA210 please.");
      }
    }
    private void comboBox5_TextChanged(object sender, EventArgs e)
    {
        SelectPresets();
    }

    private void SelectPresets()
    {
        #region bullshit
        if (this.comboBoxXYPreset.Text == "KTC/TCL_26inches_above")
        {
            this.uColorTempMode = 0;
            this.uColorTempStd[0, 0] = 2700;
            this.richTextBox4.Text = "0.270";
            this.uColorTempStd[0, 1] = 2700;
            this.richTextBox5.Text = "0.270";
            this.uColorTempStd[1, 0] = 2800;
            this.richTextBox8.Text = "0.280";
            this.uColorTempStd[1, 1] = 2900;
            this.richTextBox9.Text = "0.290";
            this.uColorTempStd[2, 0] = 3000;
            this.richTextBox6.Text = "0.300";
            this.uColorTempStd[2, 1] = 3050;
            this.richTextBox7.Text = "0.305";
            this.uColorTempReadOnly(true);
        }
        else if (this.comboBoxXYPreset.Text == "KTC/TCL_26inches_below")
        {
            this.uColorTempMode = 1;
            this.uColorTempStd[0, 0] = 2850;
            this.richTextBox4.Text = "0.285";
            this.uColorTempStd[0, 1] = 2850;
            this.richTextBox5.Text = "0.285";
            this.uColorTempStd[1, 0] = 2950;
            this.richTextBox8.Text = "0.295";
            this.uColorTempStd[1, 1] = 3050;
            this.richTextBox9.Text = "0.305";
            this.uColorTempStd[2, 0] = 3150;
            this.richTextBox6.Text = "0.315";
            this.uColorTempStd[2, 1] = 3200;
            this.richTextBox7.Text = "0.320";
            this.uColorTempReadOnly(true);
        }
        else if (this.comboBoxXYPreset.Text == "BNC")
        {
            this.uColorTempMode = 2;
            this.uColorTempStd[0, 0] = 2700;
            this.richTextBox4.Text = "0.270";
            this.uColorTempStd[0, 1] = 2700;
            this.richTextBox5.Text = "0.270";
            this.uColorTempStd[1, 0] = 2800;
            this.richTextBox8.Text = "0.280";
            this.uColorTempStd[1, 1] = 2900;
            this.richTextBox9.Text = "0.290";
            this.uColorTempStd[2, 0] = 3130;
            this.richTextBox6.Text = "0.313";
            this.uColorTempStd[2, 1] = 3290;
            this.richTextBox7.Text = "0.329";
            this.uColorTempReadOnly(true);
        }
        else if (this.comboBoxXYPreset.Text == "BenQ_LED")
        {
            this.uColorTempMode = 3;
            this.uColorTempStd[0, 0] = 2780;
            this.richTextBox4.Text = "0.278";
            this.uColorTempStd[0, 1] = 2780;
            this.richTextBox5.Text = "0.278";
            this.uColorTempStd[1, 0] = 2830;
            this.richTextBox8.Text = "0.283";
            this.uColorTempStd[1, 1] = 2970;
            this.richTextBox9.Text = "0.297";
            this.uColorTempStd[2, 0] = 3130;
            this.richTextBox6.Text = "0.313";
            this.uColorTempStd[2, 1] = 3290;
            this.richTextBox7.Text = "0.329";
            this.uColorTempReadOnly(true);
        }
        else if (this.comboBoxXYPreset.Text == "ROWA")
        {
            this.uColorTempMode = 4;
            this.uColorTempStd[0, 0] = 2700;
            this.richTextBox4.Text = "0.270";
            this.uColorTempStd[0, 1] = 2740;
            this.richTextBox5.Text = "0.274";
            this.uColorTempStd[1, 0] = 2810;
            this.richTextBox8.Text = "0.281";
            this.uColorTempStd[1, 1] = 2920;
            this.richTextBox9.Text = "0.292";
            this.uColorTempStd[2, 0] = 2920;
            this.richTextBox6.Text = "0.292";
            this.uColorTempStd[2, 1] = 3000;
            this.richTextBox7.Text = "0.300";
            this.uColorTempReadOnly(true);
        }
        else if (this.comboBoxXYPreset.Text == "Leader/Shownic")
        {
            this.uColorTempMode = 5;
            this.uColorTempStd[0, 0] = 2660;
            this.richTextBox4.Text = "0.266";
            this.uColorTempStd[0, 1] = 2760;
            this.richTextBox5.Text = "0.276";
            this.uColorTempStd[1, 0] = 2730;
            this.richTextBox8.Text = "0.273";
            this.uColorTempStd[1, 1] = 2850;
            this.richTextBox9.Text = "0.285";
            this.uColorTempStd[2, 0] = 2830;
            this.richTextBox6.Text = "0.283";
            this.uColorTempStd[2, 1] = 2970;
            this.richTextBox7.Text = "0.297";
            this.uColorTempReadOnly(true);
        }
        else if (this.comboBoxXYPreset.Text == "BOE")
        {
            this.uColorTempMode = 6;
            this.uColorTempStd[0, 0] = 2720;
            this.richTextBox4.Text = "0.272";
            this.uColorTempStd[0, 1] = 2770;
            this.richTextBox5.Text = "0.277";
            this.uColorTempStd[1, 0] = 2850;
            this.richTextBox8.Text = "0.285";
            this.uColorTempStd[1, 1] = 2930;
            this.richTextBox9.Text = "0.293";
            this.uColorTempStd[2, 0] = 3130;
            this.richTextBox6.Text = "0.313";
            this.uColorTempStd[2, 1] = 3230;
            this.richTextBox7.Text = "0.323";
            this.uColorTempReadOnly(true);
        }
        else if (this.comboBoxXYPreset.Text == "Hyundai")
        {
            this.uColorTempMode = 7;
            this.uColorTempStd[0, 0] = 2700;
            this.richTextBox4.Text = "0.270";
            this.uColorTempStd[0, 1] = 2800;
            this.richTextBox5.Text = "0.280";
            this.uColorTempStd[1, 0] = 2810;
            this.richTextBox8.Text = "0.281";
            this.uColorTempStd[1, 1] = 2940;
            this.richTextBox9.Text = "0.294";
            this.uColorTempStd[2, 0] = 3130;
            this.richTextBox6.Text = "0.313";
            this.uColorTempStd[2, 1] = 3290;
            this.richTextBox7.Text = "0.329";
            this.uColorTempReadOnly(true);
        }
        else if (this.comboBoxXYPreset.Text == "Daewoo")
        {
            this.uColorTempMode = 8;
            this.uColorTempStd[0, 0] = 2610;
            this.richTextBox4.Text = "0.261";
            this.uColorTempStd[0, 1] = 2810;
            this.richTextBox5.Text = "0.281";
            this.uColorTempStd[1, 0] = 2770;
            this.richTextBox8.Text = "0.277";
            this.uColorTempStd[1, 1] = 2970;
            this.richTextBox9.Text = "0.297";
            this.uColorTempStd[2, 0] = 2960;
            this.richTextBox6.Text = "0.296";
            this.uColorTempStd[2, 1] = 3180;
            this.richTextBox7.Text = "0.318";
            this.uColorTempReadOnly(true);
        }
        else if (this.comboBoxXYPreset.Text == "SINGSUNG_26inches_above")
        {
            this.uColorTempMode = 9;
            this.uColorTempStd[0, 0] = 2550;
            this.richTextBox4.Text = "0.255";
            this.uColorTempStd[0, 1] = 2750;
            this.richTextBox5.Text = "0.275";
            this.uColorTempStd[1, 0] = 2700;
            this.richTextBox8.Text = "0.270";
            this.uColorTempStd[1, 1] = 2900;
            this.richTextBox9.Text = "0.290";
            this.uColorTempStd[2, 0] = 2800;
            this.richTextBox6.Text = "0.280";
            this.uColorTempStd[2, 1] = 3050;
            this.richTextBox7.Text = "0.305";
            this.uColorTempReadOnly(true);
        }
        else if (this.comboBoxXYPreset.Text == "SINGSUNG_26inches_below")
        {
            this.uColorTempMode = 10;
            this.uColorTempStd[0, 0] = 2550;
            this.richTextBox4.Text = "0.255";
            this.uColorTempStd[0, 1] = 2700;
            this.richTextBox5.Text = "0.270";
            this.uColorTempStd[1, 0] = 2650;
            this.richTextBox8.Text = "0.265";
            this.uColorTempStd[1, 1] = 2800;
            this.richTextBox9.Text = "0.280";
            this.uColorTempStd[2, 0] = 2800;
            this.richTextBox6.Text = "0.280";
            this.uColorTempStd[2, 1] = 3000;
            this.richTextBox7.Text = "0.300";
            this.uColorTempReadOnly(true);
        }
        else if (this.comboBoxXYPreset.Text == "PHILIPS_export")
        {
            this.uColorTempMode = 11;
            this.uColorTempStd[0, 0] = 2760;
            this.richTextBox4.Text = "0.276";
            this.uColorTempStd[0, 1] = 2800;
            this.richTextBox5.Text = "0.280";
            this.uColorTempStd[1, 0] = 2870;
            this.richTextBox8.Text = "0.287";
            this.uColorTempStd[1, 1] = 2960;
            this.richTextBox9.Text = "0.296";
            this.uColorTempStd[2, 0] = 3130;
            this.richTextBox6.Text = "0.313";
            this.uColorTempStd[2, 1] = 3290;
            this.richTextBox7.Text = "0.329";
            this.uColorTempReadOnly(true);
        }
        else if (this.comboBoxXYPreset.Text == "PHILIPS_32inches_above")
        {
            this.uColorTempMode = 12;
            this.uColorTempStd[0, 0] = 2710;
            this.richTextBox4.Text = "0.271";
            this.uColorTempStd[0, 1] = 2740;
            this.richTextBox5.Text = "0.274";
            this.uColorTempStd[1, 0] = 2850;
            this.richTextBox8.Text = "0.285";
            this.uColorTempStd[1, 1] = 2930;
            this.richTextBox9.Text = "0.293";
            this.uColorTempStd[2, 0] = 3050;
            this.richTextBox6.Text = "0.305";
            this.uColorTempStd[2, 1] = 3110;
            this.richTextBox7.Text = "0.311";
            this.uColorTempReadOnly(true);
        }
        else if (this.comboBoxXYPreset.Text == "PHILIPS_32inches_below")
        {
            this.uColorTempMode = 13;
            this.uColorTempStd[0, 0] = 2850;
            this.richTextBox4.Text = "0.285";
            this.uColorTempStd[0, 1] = 2930;
            this.richTextBox5.Text = "0.293";
            this.uColorTempStd[1, 0] = 2950;
            this.richTextBox8.Text = "0.295";
            this.uColorTempStd[1, 1] = 3050;
            this.richTextBox9.Text = "0.305";
            this.uColorTempStd[2, 0] = 3130;
            this.richTextBox6.Text = "0.313";
            this.uColorTempStd[2, 1] = 3290;
            this.richTextBox7.Text = "0.329";
            this.uColorTempReadOnly(true);
        }
        else if (this.comboBoxXYPreset.Text == "PANDA")
        {
            this.uColorTempMode = 14;
            this.uColorTempStd[0, 0] = 2740;
            this.richTextBox4.Text = "0.274";
            this.uColorTempStd[0, 1] = 2860;
            this.richTextBox5.Text = "0.286";
            this.uColorTempStd[1, 0] = 2840;
            this.richTextBox8.Text = "0.284";
            this.uColorTempStd[1, 1] = 2990;
            this.richTextBox9.Text = "0.299";
            this.uColorTempStd[2, 0] = 3130;
            this.richTextBox6.Text = "0.313";
            this.uColorTempStd[2, 1] = 3290;
            this.richTextBox7.Text = "0.329";
            this.uColorTempReadOnly(true);
        }
        else if (this.comboBoxXYPreset.Text == "Panasonic/Sanyo")
        {
            this.uColorTempMode = 15;
            this.uColorTempStd[0, 0] = 2640;
            this.richTextBox4.Text = "0.264";
            this.uColorTempStd[0, 1] = 2720;
            this.richTextBox5.Text = "0.272";
            this.uColorTempStd[1, 0] = 2760;
            this.richTextBox8.Text = "0.276";
            this.uColorTempStd[1, 1] = 2820;
            this.richTextBox9.Text = "0.282";
            this.uColorTempStd[2, 0] = 2880;
            this.richTextBox6.Text = "0.288";
            this.uColorTempStd[2, 1] = 2910;
            this.richTextBox7.Text = "0.291";
            this.uColorTempReadOnly(true);
        }
#endregion
        else if (this.comboBoxXYPreset.Text == "User_defined_color_temp")
        {
			  this.uColorTempMode = 16;
			  try
			  {
				  var get = new SavingManager(PublicData.FindSectionInTreeBySection(WBSetSection));
				  this.richTextBox4.Text = get.Key(Setting.CoolX).Value;
				  this.richTextBox5.Text = get.Key(Setting.CoolY).Value;
				  this.richTextBox8.Text = get.Key(Setting.StandartX).Value;
				  this.richTextBox9.Text = get.Key(Setting.StandartY).Value;
				  this.richTextBox6.Text = get.Key(Setting.WarmX).Value;
				  this.richTextBox7.Text = get.Key(Setting.WarmY).Value;
				  this.comboBoxToleranceXY.Text = get.Key(Setting.ToleranceXY).Value;
				  this.uColorTempReadOnly(false);
			  }
			  catch (Exception ex)
			  {
				  MessageBox.Show(WBSetSection + "Error.\n" + ex.Message);
			  }
        }
        #region bullshit
        else
        {
            this.uColorTempMode = 0;
            this.uColorTempStd[0, 0] = 2700;
            this.richTextBox4.Text = "0.270";
            this.uColorTempStd[0, 1] = 2700;
            this.richTextBox5.Text = "0.270";
            this.uColorTempStd[1, 0] = 2800;
            this.richTextBox8.Text = "0.280";
            this.uColorTempStd[1, 1] = 2900;
            this.richTextBox9.Text = "0.290";
            this.uColorTempStd[2, 0] = 3000;
            this.richTextBox6.Text = "0.300";
            this.uColorTempStd[2, 1] = 3050;
            this.richTextBox7.Text = "0.305";
            this.uColorTempReadOnly(true);
        }
        if (this.comboBoxXYPreset.Text == "Panasonic/Sanyo")
        {
            this.comboBox4.Enabled = true;
            this.comboBox6.Enabled = true;
            this.comboBox7.Enabled = true;
        }
        else
        {
            this.comboBox4.Enabled = false;
            this.comboBox6.Enabled = false;
            this.comboBox7.Enabled = false;
        }
        #endregion
        this.richTextBoxCoolLvPercent.Text = "75%";
        this.richTextBoxNormLvPercent.Text = "85%";
        this.richTextBoxWarmLvPercent.Text = "75%";
    }
    private void uColorTempReadOnly(bool ucOption)
    {
      if (ucOption)
      {
        this.richTextBox4.ReadOnly = true;
        this.richTextBox5.ReadOnly = true;
        this.richTextBox6.ReadOnly = true;
        this.richTextBox7.ReadOnly = true;
        this.richTextBox8.ReadOnly = true;
        this.richTextBox9.ReadOnly = true;
        this.richTextBox4.BackColor = SystemColors.Control;
        this.richTextBox5.BackColor = SystemColors.Control;
        this.richTextBox6.BackColor = SystemColors.Control;
        this.richTextBox7.BackColor = SystemColors.Control;
        this.richTextBox8.BackColor = SystemColors.Control;
        this.richTextBox9.BackColor = SystemColors.Control;
      }
      else
      {
        this.richTextBox4.ReadOnly = false;
        this.richTextBox5.ReadOnly = false;
        this.richTextBox6.ReadOnly = false;
        this.richTextBox7.ReadOnly = false;
        this.richTextBox8.ReadOnly = false;
        this.richTextBox9.ReadOnly = false;
        this.richTextBox4.BackColor = SystemColors.ControlLightLight;
        this.richTextBox5.BackColor = SystemColors.ControlLightLight;
        this.richTextBox6.BackColor = SystemColors.ControlLightLight;
        this.richTextBox7.BackColor = SystemColors.ControlLightLight;
        this.richTextBox8.BackColor = SystemColors.ControlLightLight;
        this.richTextBox9.BackColor = SystemColors.ControlLightLight;
      }
    }
    private void comboBox2_TextChanged(object sender, EventArgs e)
    {
      if (this.comboBoxToleranceXY.Text == "0.005")
        this.Temp_Tolerance = 50f;
      else if (this.comboBoxToleranceXY.Text == "0.010")
        this.Temp_Tolerance = 100f;
      else
        this.Temp_Tolerance = 50f;
    }
    private void richTextBox4_TextChanged(object sender, EventArgs e)
    {
      try
      {
        if (this.richTextBox4.Text.Length < 7)
        {
          this.uColorTempStd[0, 0] = int.Parse(this.richTextBox4.Text.Substring(2, this.richTextBox4.Text.Length - 2)) * 10;
        }
        else
        {
          int num = (int) MessageBox.Show("Input invalid!");
        }
      }
      catch
      {
        int num = (int) MessageBox.Show("Input invalid!");
      }
    }
    private void richTextBox5_TextChanged(object sender, EventArgs e)
    {
      try
      {
        if (this.richTextBox5.Text.Length < 7)
        {
          this.uColorTempStd[0, 1] = int.Parse(this.richTextBox5.Text.Substring(2, this.richTextBox5.Text.Length - 2)) * 10;
        }
        else
        {
          int num = (int) MessageBox.Show("Input invalid!");
        }
      }
      catch
      {
        int num = (int) MessageBox.Show("Input invalid!");
      }
    }
    private void richTextBox6_TextChanged(object sender, EventArgs e)
    {
      try
      {
        if (this.richTextBox6.Text.Length < 7)
        {
          this.uColorTempStd[2, 0] = int.Parse(this.richTextBox6.Text.Substring(2, this.richTextBox6.Text.Length - 2)) * 10;
        }
        else
        {
          int num = (int) MessageBox.Show("Input invalid!");
        }
      }
      catch
      {
        int num = (int) MessageBox.Show("Input invalid!");
      }
    }
    private void richTextBox7_TextChanged(object sender, EventArgs e)
    {
      try
      {
        if (this.richTextBox7.Text.Length < 7)
        {
          this.uColorTempStd[2, 1] = int.Parse(this.richTextBox7.Text.Substring(2, this.richTextBox7.Text.Length - 2)) * 10;
        }
        else
        {
          int num = (int) MessageBox.Show("Input invalid!");
        }
      }
      catch
      {
        int num = (int) MessageBox.Show("Input invalid!");
      }
    }
    private void richTextBox8_TextChanged(object sender, EventArgs e)
    {
      try
      {
        if (this.richTextBox8.Text.Length < 7)
        {
          this.uColorTempStd[1, 0] = int.Parse(this.richTextBox8.Text.Substring(2, this.richTextBox8.Text.Length - 2)) * 10;
        }
        else
        {
          int num = (int) MessageBox.Show("Input invalid!");
        }
      }
      catch
      {
        int num = (int) MessageBox.Show("Input invalid!");
      }
    }
    private void richTextBox9_TextChanged(object sender, EventArgs e)
    {
      try
      {
        if (this.richTextBox9.Text.Length < 7)
        {
          this.uColorTempStd[1, 1] = int.Parse(this.richTextBox9.Text.Substring(2, this.richTextBox9.Text.Length - 2)) * 10;
        }
        else
        {
          int num = (int) MessageBox.Show("Input invalid!");
        }
      }
      catch
      {
        int num = (int) MessageBox.Show("Input invalid!");
      }
    }    
    private bool check_cmd_return()
    {
      if (!this.EnableReturnCommand)
        return true;
      if (!this.uUartReceiveFlag)
        return false;
      this.uUartReceiveFlag = false;
      return this.TVReturnStatus == 0;
    }
    private void richTextBox32_TextChanged(object sender, EventArgs e)
    {
      try
      {
        this.Cool_TargetBrightness = float.Parse(this.richTextBox32.Text);
      }
      catch
      {
        int num = (int) MessageBox.Show("Input invalid!");
      }
    }
    private void richTextBox37_TextChanged(object sender, EventArgs e)
    {
      try
      {
        this.Standard_TargetBrightness = float.Parse(this.richTextBox37.Text);
      }
      catch
      {
        int num = (int) MessageBox.Show("Input invalid!");
      }
    }
    private void richTextBox38_TextChanged(object sender, EventArgs e)
    {
      try
      {
        this.Warm_TargetBrightness = float.Parse(this.richTextBox38.Text);
      }
      catch
      {
        int num = (int) MessageBox.Show("Input invalid!");
      }
    }
    private void richTextBox33_TextChanged(object sender, EventArgs e)
    {
      try
      {
        this.Brightness_Tolerance = (float) ((double) float.Parse(this.richTextBoxToleranceLv.Text) * 
            (double) this.Panel_Lv_max / 100.0);
      }
      catch
      {
        int num = (int) MessageBox.Show("Input invalid!");
      }
    }
    private void button3_Click(object sender, EventArgs e)
    {
      this.SaveDefaultData = false;
      this.SaveDataNumber = 0;
      this.richTextBox20.Text = this.SaveDataNumber.ToString();
      this.buttonDefault.Enabled = false;
      this.buttonDefault.BackColor = Color.Green;
      this.buttonAverage.Enabled = false;
      this.buttonAverage.BackColor = SystemColors.Control;
      this.InitValueType = ColorSystemTools.InitValue.DefaultValue;
      if (!File.Exists("temp_data.txt"))
        return;
      using (StreamWriter streamWriter = new StreamWriter("temp_data.txt", false))
      {
        streamWriter.WriteLine("0," + "128" + "," + "128" + "," + "128");
        streamWriter.WriteLine("1," + "128" + "," + "128" + "," + "128");
        streamWriter.WriteLine("2," + "128" + "," + "128" + "," + "128");
        streamWriter.Close();
      }
      this.uColorTemp_Table[0, 0] = (byte) 128;
      this.uColorTemp_Table[0, 1] = (byte) 128;
      this.uColorTemp_Table[0, 2] = (byte) 128;
      this.uColorTemp_Table[1, 0] = (byte) 128;
      this.uColorTemp_Table[1, 1] = (byte) 128;
      this.uColorTemp_Table[1, 2] = (byte) 128;
      this.uColorTemp_Table[2, 0] = (byte) 128;
      this.uColorTemp_Table[2, 1] = (byte) 128;
      this.uColorTemp_Table[2, 2] = (byte) 128;
      this.richTextBox30.Text = this.uColorTemp_Table[0, 0].ToString();
      this.richTextBox27.Text = this.uColorTemp_Table[0, 1].ToString();
      this.richTextBox24.Text = this.uColorTemp_Table[0, 2].ToString();
      this.richTextBox29.Text = this.uColorTemp_Table[1, 0].ToString();
      this.richTextBox26.Text = this.uColorTemp_Table[1, 1].ToString();
      this.richTextBox23.Text = this.uColorTemp_Table[1, 2].ToString();
      this.richTextBox28.Text = this.uColorTemp_Table[2, 0].ToString();
      this.richTextBox25.Text = this.uColorTemp_Table[2, 1].ToString();
      this.richTextBox22.Text = this.uColorTemp_Table[2, 2].ToString();
      this.richTextBoxG.Text = this.uColorTemp_Table[1, 1].ToString();
      if (!File.Exists("start_data.txt"))
        return;
      using (StreamWriter streamWriter = new StreamWriter("start_data.txt", false))
      {
        streamWriter.WriteLine(  " 0" +  "," +   " 0" + "," +   " 0" + "," +   " 0" + "," +   " 0");
        streamWriter.WriteLine(  " 1" +  "," +   " 0" + "," +   " 0" + "," +   " 0" + "," +   " 0");
        streamWriter.WriteLine(  " 2" +  "," +   " 0" + "," +   " 0" + "," +   " 0" + "," +   " 0");
        streamWriter.WriteLine(  " 3" +  "," +   " 128");
        streamWriter.Close();
      }
      for (int index1 = 0; index1 < 3; ++index1)
      {
        this.uColorTemp_StartStepIndex[index1] = 0;
        for (int index2 = 0; index2 < 4; ++index2)
          this.uColorTemp_StartStepSum[index1, index2] = 0;
      }
      this.richTextBoxCoolLvPercent.Text = "75" +   "%";
      this.richTextBoxNormLvPercent.Text = "85" +   "%";
      this.richTextBoxWarmLvPercent.Text = "75" +   "%";
      this.richTextBoxCoolLvPercent.ForeColor = SystemColors.WindowText;
      this.richTextBoxNormLvPercent.ForeColor = SystemColors.WindowText;
      this.richTextBoxWarmLvPercent.ForeColor = SystemColors.WindowText;
      this.richTextBoxG.ForeColor = SystemColors.WindowText;
    }
    private void buttonDefault_Click(object sender, EventArgs e)
    {
      if (!File.Exists("temp_data.txt"))
        return;
      using (StreamReader streamReader = File.OpenText("temp_data.txt"))
      {
        string str;
        while ((str = streamReader.ReadLine()) != null)
        {
          string[] strArray = str.Split(',');
          if (int.Parse(strArray[0]) == 0)
          {
            this.uColorTemp_Table[0, 0] = byte.Parse(strArray[1]);
            this.uColorTemp_Table[0, 1] = byte.Parse(strArray[2]);
            this.uColorTemp_Table[0, 2] = byte.Parse(strArray[3]);
          }
          else if (int.Parse(strArray[0]) == 1)
          {
            this.uColorTemp_Table[1, 0] = byte.Parse(strArray[1]);
            this.uColorTemp_Table[1, 1] = byte.Parse(strArray[2]);
            this.uColorTemp_Table[1, 2] = byte.Parse(strArray[3]);
          }
          else if (int.Parse(strArray[0]) == 2)
          {
            this.uColorTemp_Table[2, 0] = byte.Parse(strArray[1]);
            this.uColorTemp_Table[2, 1] = byte.Parse(strArray[2]);
            this.uColorTemp_Table[2, 2] = byte.Parse(strArray[3]);
            break;
          }
        }
        streamReader.Close();
      }
      this.richTextBox30.Text = this.uColorTemp_Table[0, 0].ToString();
      this.richTextBox27.Text = this.uColorTemp_Table[0, 1].ToString();
      this.richTextBox24.Text = this.uColorTemp_Table[0, 2].ToString();
      this.richTextBox29.Text = this.uColorTemp_Table[1, 0].ToString();
      this.richTextBox26.Text = this.uColorTemp_Table[1, 1].ToString();
      this.richTextBox23.Text = this.uColorTemp_Table[1, 2].ToString();
      this.richTextBox28.Text = this.uColorTemp_Table[2, 0].ToString();
      this.richTextBox25.Text = this.uColorTemp_Table[2, 1].ToString();
      this.richTextBox22.Text = this.uColorTemp_Table[2, 2].ToString();
      this.richTextBoxG.Text = this.uColorTemp_Table[1, 1].ToString();
      this.buttonDefault.Enabled = false;
      this.buttonDefault.BackColor = Color.Green;
      this.buttonAverage.Enabled = true;
      this.buttonAverage.BackColor = SystemColors.Control;
      this.InitValueType = ColorSystemTools.InitValue.DefaultValue;
    }
    private void buttonAverage_Click(object sender, EventArgs e)
    {
      if (!File.Exists("temp_data.txt"))
        return;
      using (StreamReader streamReader = File.OpenText("temp_data.txt"))
      {
        int[] numArray1 = new int[3];
        int[] numArray2 = new int[3];
        int[] numArray3 = new int[3];
        string str;
        while ((str = streamReader.ReadLine()) != null)
        {
          string[] strArray = str.Split(',');
          if (int.Parse(strArray[0]) >= 10)
          {
            numArray1[int.Parse(strArray[0]) % 10] += int.Parse(strArray[1]);
            numArray2[int.Parse(strArray[0]) % 10] += int.Parse(strArray[2]);
            numArray3[int.Parse(strArray[0]) % 10] += int.Parse(strArray[3]);
            this.SaveDataNumber = int.Parse(strArray[0]) / 10;
          }
        }
        try
        {
          this.uColorTemp_Table[0, 0] = (byte) (numArray1[0] / this.SaveDataNumber);
          this.uColorTemp_Table[0, 1] = (byte) (numArray2[0] / this.SaveDataNumber);
          this.uColorTemp_Table[0, 2] = (byte) (numArray3[0] / this.SaveDataNumber);
          this.uColorTemp_Table[1, 0] = (byte) (numArray1[1] / this.SaveDataNumber);
          this.uColorTemp_Table[1, 1] = (byte) (numArray2[1] / this.SaveDataNumber);
          this.uColorTemp_Table[1, 2] = (byte) (numArray3[1] / this.SaveDataNumber);
          this.uColorTemp_Table[2, 0] = (byte) (numArray1[2] / this.SaveDataNumber);
          this.uColorTemp_Table[2, 1] = (byte) (numArray2[2] / this.SaveDataNumber);
          this.uColorTemp_Table[2, 2] = (byte) (numArray3[2] / this.SaveDataNumber);
        }
        catch
        {
          int num = (int) MessageBox.Show(" No saved data. ");
        }
        streamReader.Close();
      }
      this.richTextBox20.Text = this.SaveDataNumber.ToString();
      this.richTextBox30.Text = this.uColorTemp_Table[0, 0].ToString();
      this.richTextBox27.Text = this.uColorTemp_Table[0, 1].ToString();
      this.richTextBox24.Text = this.uColorTemp_Table[0, 2].ToString();
      this.richTextBox29.Text = this.uColorTemp_Table[1, 0].ToString();
      this.richTextBox26.Text = this.uColorTemp_Table[1, 1].ToString();
      this.richTextBox23.Text = this.uColorTemp_Table[1, 2].ToString();
      this.richTextBox28.Text = this.uColorTemp_Table[2, 0].ToString();
      this.richTextBox25.Text = this.uColorTemp_Table[2, 1].ToString();
      this.richTextBox22.Text = this.uColorTemp_Table[2, 2].ToString();
      this.richTextBoxG.Text = this.uColorTemp_Table[1, 1].ToString();
      this.buttonDefault.Enabled = true;
      this.buttonDefault.BackColor = SystemColors.Control;
      this.buttonAverage.Enabled = false;
      this.buttonAverage.BackColor = Color.Green;
      this.InitValueType = ColorSystemTools.InitValue.AverageVaule;
    }
    private void radioButton1_CheckedChanged(object sender, EventArgs e)
    {
      if (!this.radioButton1.Checked)
        return;
      this.radioButton2.Checked = false;
      this.UseMaxPanelLv75Percent = true;
      this.richTextBox32.ReadOnly = true;
      this.richTextBox32.BackColor = SystemColors.Control;
      this.richTextBox32.Text = "210";
      this.richTextBox37.ReadOnly = true;
      this.richTextBox37.BackColor = SystemColors.Control;
      this.richTextBox37.Text = "210";
      this.richTextBox38.ReadOnly = true;
      this.richTextBox38.BackColor = SystemColors.Control;
      this.richTextBox38.Text = "210";
    }
    private void radioButton2_CheckedChanged(object sender, EventArgs e)
    {
      if (!this.radioButton2.Checked)
        return;
      this.radioButton1.Checked = false;
      this.UseMaxPanelLv75Percent = false;
      this.richTextBox32.ReadOnly = false;
      this.richTextBox32.BackColor = SystemColors.ControlLightLight;
      this.richTextBox32.Text = this.Cool_TargetBrightness.ToString();
      this.richTextBox37.ReadOnly = false;
      this.richTextBox37.BackColor = SystemColors.ControlLightLight;
      this.richTextBox37.Text = this.Standard_TargetBrightness.ToString();
      this.richTextBox38.ReadOnly = false;
      this.richTextBox38.BackColor = SystemColors.ControlLightLight;
      this.richTextBox38.Text = this.Warm_TargetBrightness.ToString();
    }
    private void radioButtonGreen128Yes_CheckedChanged(object sender, EventArgs e)
    {
        if (!this.radioButtonGreen128Yes.Checked)
        {
            radioButtonGreen128No.Checked = true;
            return;
        }
        this.radioButtonGreen128No.Checked = false;
        this.StandardGGainGreaterThan128 = false;
    }
    private void radioButtonGreen128No_CheckedChanged(object sender, EventArgs e)
    {
      if (!this.radioButtonGreen128No.Checked)
        return;
      this.radioButtonGreen128Yes.Checked = false;
      this.StandardGGainGreaterThan128 = true;
    }
    private void radioButton5_CheckedChanged(object sender, EventArgs e)
    {
      if (!this.radioButton5.Checked)
        return;
      this.radioButton6.Checked = false;
      this.EnableReturnCommand = true;
    }
    private void radioButton6_CheckedChanged(object sender, EventArgs e)
    {
      if (!this.radioButton6.Checked)
        return;
      this.radioButton5.Checked = false;
      this.EnableReturnCommand = false;
    }
    private void radioButton7_CheckedChanged(object sender, EventArgs e)
    {
      if (!this.radioButton7.Checked)
        return;
      this.radioButton8.Checked = false;
      this.TargetType_Monitor = false;
      this.comboBox3.Text = "115200";
      this.uBaudrate = Convert.ToInt32(this.comboBox3.Text);
      //this.serialPort1.BaudRate = this.uBaudrate;
      this.radioButtonGreen128No.Checked = true;
      this.radioButtonGreen128Yes.Checked = false;
      this.StandardGGainGreaterThan128 = true;
      this.radioButtonGreen128Yes.Enabled = true;
      this.radioButtonGreen128No.Enabled = true;
      this.radioButton5.Enabled = true;
      this.radioButton6.Enabled = true;
    }
    private void radioButton8_CheckedChanged(object sender, EventArgs e)
    {
      if (!this.radioButton8.Checked)
        return;
      this.radioButton7.Checked = false;
      this.TargetType_Monitor = true;
      this.comboBox3.Text = "128000";
      this.uBaudrate = Convert.ToInt32(this.comboBox3.Text);
      //this.serialPort1.BaudRate = this.uBaudrate;
      this.radioButtonGreen128Yes.Checked = true;
      this.radioButtonGreen128No.Checked = false;
      this.StandardGGainGreaterThan128 = false;
      this.radioButtonGreen128Yes.Enabled = false;
      this.radioButtonGreen128No.Enabled = false;
      this.radioButton5.Enabled = false;
      this.radioButton6.Enabled = false;
    }
    public struct GAMMA_POINT_ARRAY
    {
      public double x;
      public double y;
    }
    public enum RS232_CMD
    {
      INPUT_SOURCE_com,
      TEMPERATURE_com,
      R_GAIN_com,
      G_GAIN_com,
      B_GAIN_com,
      R_OFFSET_com,
      G_OFFSET_com,
      B_OFFSET_com,
      COPY_TO_All_SOURCE_com,
      ADC_CALIBRATION_com,
      WHITE_PATTERN_com,
      GET_RGB_GAIN_DATA_com,
      RGB_GAIN_VALUE_com,
      R_GAIN_VALUE_com,
      G_GAIN_VALUE_com,
      B_GAIN_VALUE_com,
      AUTO_ADJUST_MODE_com,
    }
    public enum ColorTempNCW
    {
      Cool,
      Normal,
      Warm,
    }
    public enum ColorTempGain
    {
      Red,
      Green,
      Blue,
    }
    public enum InitValue
    {
      DefaultValue,
      AverageVaule,
    }

    private void ColorSystemTools_Shown(object sender, EventArgs e)
    {
        Start();
    }

    private void ColorSystemTools_Load(object sender, EventArgs e)
    {
		 comboBoxXYPreset.Text = "User_defined_color_temp";
		 try
		 {
			 var get = new SavingManager(PublicData.FindSectionInTreeBySection(WBSetSection));
			 radioButtonGreen128Yes.Checked = get.Key(Setting.Green128Below).ValueBool;
		 }
		 catch (Exception ex)
		 {
			 MessageBox.Show(WBSetSection + "Error.\n" + ex.Message);
		 }
    }
  }
}
